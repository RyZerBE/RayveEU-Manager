<?php

declare(strict_types=1);

namespace manager\util;

class FileUtils {
    public static function delete(string $path): void {
        @mkdir($path);
        @exec("sudo rm -r ".$path);
    }

    public static function copy(string $source, string $destination): void {
        if(is_file($source)) {
            self::copyFile($source, $destination);
            return;
        }
        self::copyDirectory($source, $destination);
    }

    protected static function copyDirectory(string $source, string $destination): void {
        @mkdir($destination);
        @exec("sudo cp ".$source."/* ".$destination."/ -r");
    }

    protected static function copyFile(string $source, string $destination): void {
        @exec("sudo cp ".$source." ".$destination."/ -r");
    }
}