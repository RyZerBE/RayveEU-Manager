<?php

declare(strict_types=1);

namespace manager\util;

use mysqli;

class Database {
    public static function setup(mysqli $mysqli): void {
        //Player Tables
        $mysqli->query("CREATE TABLE IF NOT EXISTS player_data(xboxid VARCHAR(16) NOT NULL, PRIMARY KEY (`xboxid`), username VARCHAR(32) NOT NULL, first_join TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP , last_join TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP, online_time INT NOT NULL DEFAULT 0, account_detection_bypass INT NOT NULL DEFAULT 0, play_fab_id VARCHAR(512) NOT NULL, client_random_id VARCHAR(512) NOT NULL, version VARCHAR(16) NOT NULL)");
        $mysqli->query("CREATE TABLE IF NOT EXISTS player_settings(xboxid VARCHAR(16) NOT NULL, PRIMARY KEY (`xboxid`), settings TEXT NOT NULL)");
        $mysqli->query("CREATE TABLE IF NOT EXISTS player_statistics(id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`), xboxid VARCHAR(16) NOT NULL, statistic_key VARCHAR(64) NOT NULL, statistic_value INT NOT NULL, date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)");
        $mysqli->query("CREATE TABLE IF NOT EXISTS player_currencies(id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`), xboxid VARCHAR(16) NOT NULL, currency VARCHAR(64) NOT NULL, amount INT NOT NULL DEFAULT '0' )");
        $mysqli->query("CREATE TABLE IF NOT EXISTS player_devices(id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`), xboxid VARCHAR(16) NOT NULL, device_id TEXT NOT NULL)");
        $mysqli->query("CREATE TABLE IF NOT EXISTS player_addresses(id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`), xboxid VARCHAR(16) NOT NULL, address VARCHAR(128) NOT NULL)");
        $mysqli->query("CREATE TABLE IF NOT EXISTS player_punishments(id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`), xboxid VARCHAR(16) NOT NULL, punisher_xboxid VARCHAR(16) DEFAULT NULL, type INT NOT NULL, date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, until TIMESTAMP NULL DEFAULT NULL)");
        $mysqli->query("CREATE TABLE IF NOT EXISTS player_inventories(id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`), xboxid VARCHAR(16) NOT NULL, inv_key VARCHAR(64) NOT NULL, inventory TEXT NOT NULL)");
        $mysqli->query("CREATE TABLE IF NOT EXISTS player_friends(id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`), xboxid_1 VARCHAR(16) NOT NULL, xboxid_2 VARCHAR(16) NOT NULL)");
        $mysqli->query("CREATE TABLE IF NOT EXISTS player_close_friends(xboxid VARCHAR(16) NOT NULL, PRIMARY KEY (`xboxid`), friends TEXT NOT NULL)");
        $mysqli->query("CREATE TABLE IF NOT EXISTS player_replays(id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`), xboxid VARCHAR(16) NOT NULL, replay_name VARCHAR(64) NOT NULL, favourite INT NOT NULL DEFAULT '0')");

        //Language Tables
        $mysqli->query("CREATE TABLE IF NOT EXISTS translations(id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`), languages VARCHAR(8) NOT NULL, translation_key TEXT NOT NULL, translation_value TEXT NOT NULL)");

        $mysqli->query("CREATE TABLE IF NOT EXISTS server_replays(id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY (`id`), replay_data TEXT NOT NULL, name VARCHAR(64), subname VARCHAR(64), item INT NOT NULL, duration INT NOT NULL, date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)");
    }
}