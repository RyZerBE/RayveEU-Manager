<?php

declare(strict_types=1);

namespace manager\util;

use function date;
use function var_dump;

class Logger {
    public const DEBUG = false;

    public static bool $showPacketContent = false;

    public const TERMINAL_COLORS = [
        "PURPUR" => "\033[35m",
        "DARK_RED" => "\033[31m",
        "RED" => "\033[91m",
        "PINK" => "\033[95m",
        "ORANGE" => "\033[33m",
        "YELLOW" => "\033[93m",
        "LIGHT_GREEN" => "\033[92m",
        "AQUA" => "\033[96m",
        "TURQUOISE" => "\033[36m",
        "GREEN" => "\033[32m",
        "DARK_BLUE" => "\033[34m",
        "LIGHT_GRAY" => "\033[37m",
        "DARK_GRAY" => "\033[90m",
        "LIGHT_BLUE" => "\033[94m",
        "WHITE" => "\033[30m",
        "RESET" => "\033[39m",
    ];

    public const COLOR_CODES = [
        "§a" => self::TERMINAL_COLORS["LIGHT_GREEN"],
        "§b" => self::TERMINAL_COLORS["AQUA"],
        "§c" => self::TERMINAL_COLORS["RED"],
        "§d" => self::TERMINAL_COLORS["PINK"],
        "§e" => self::TERMINAL_COLORS["YELLOW"],
        "§f" => self::TERMINAL_COLORS["WHITE"],
        "§r" => self::TERMINAL_COLORS["RESET"],
        "§1" => self::TERMINAL_COLORS["DARK_BLUE"],
        "§2" => self::TERMINAL_COLORS["GREEN"],
        "§3" => self::TERMINAL_COLORS["LIGHT_GREEN"],
        "§4" => self::TERMINAL_COLORS["DARK_RED"],
        "§5" => self::TERMINAL_COLORS["PURPUR"],
        "§6" => self::TERMINAL_COLORS["ORANGE"],
        "§7" => self::TERMINAL_COLORS["LIGHT_GRAY"],
        "§8" => self::TERMINAL_COLORS["DARK_GRAY"],
        "§9" => self::TERMINAL_COLORS["LIGHT_BLUE"],
    ];

    public static function info(string $info): void{
        self::log("§aINFO§7: §a".$info);
    }

    public static function log(string $log): void{
        $log .= "§r";
        foreach(self::COLOR_CODES as $key => $color){
            $log = str_replace($key, $color, $log);
        }
        echo "[".date("H:i:s")."] ".$log.PHP_EOL;
    }

    public static function warning(string $warning): void{
        self::log("§cWARNING§7: §c".$warning);
    }

    public static function debug(string $debug): void{
        if(!Logger::DEBUG) {
            return;
        }
        self::log("§9DEBUG§7: §9".$debug);
    }

    public static function packet(string $packet): void {
        if(!self::$showPacketContent) {
            return;
        }
        self::log("§8PACKET§7: §8".$packet);
    }

    public static function dump(mixed $dump): void {
        self::log("§9DUMP§7: §9");
        var_dump($dump);
    }

    public static function error(string $error): void{
        self::log("§cERROR§7: §c".$error);
    }

    public static function command(string $command): void{
        self::log("§eCOMMAND§7: §e".$command);
    }
}