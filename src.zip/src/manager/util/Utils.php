<?php

declare(strict_types=1);

namespace manager\util;

use manager\Manager;

class Utils {
    public static function getUptime(): string {
        $uptime = (int)floor(Manager::getInstance()->getTick() / Manager::TICKS_PER_SECOND);

        $seconds = $uptime % 60;
        $minutes = floor($uptime / 60) % 60;
        $hours = floor(floor($uptime / 60) / 60) % 24;
        $days = (int)floor(floor(floor($uptime / 60) / 60) / 24);

        $uptimeMessage = "";
        if($days > 0) $uptimeMessage .= $days." day".($days === 1 ? "" : "s").", ";
        if($hours > 0) $uptimeMessage .= $hours." hour".($hours === 1 ? "" : "s").", ";
        if($minutes > 0) $uptimeMessage .= $minutes." minute".($minutes === 1 ? "" : "s").", ";
        $uptimeMessage .= $seconds." seconds";
        return $uptimeMessage;
    }
}