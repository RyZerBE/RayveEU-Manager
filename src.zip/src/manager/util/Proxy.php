<?php

declare(strict_types=1);

namespace manager\util;

class Proxy{
    public static function executeCommand(string $command): void {
        exec("screen -S Proxy -X stuff '".$command."\n'");
    }

    public static function kick(string $player, string $reason): void {
        self::executeCommand("wdkick ".$player." ".$reason);
    }
}