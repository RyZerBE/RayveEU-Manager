<?php

declare(strict_types=1);

namespace manager\util;

use manager\Manager;

final class WebhookManager {
    private static ?array $webhooks = null;

    public function __construct(){
        $file = Manager::getBasePath()."webhooks.yml";
        if(!is_file($file)) {
            file_put_contents($file, yaml_emit([]));
            return;
        }
        self::$webhooks = yaml_parse(file_get_contents(Manager::getBasePath()."webhooks.yml"));
    }

    public static function get(string $webhook): ?string {
        if(self::$webhooks === null) {
            return (new WebhookManager())::get($webhook);
        }
        return self::$webhooks[$webhook] ?? null;
    }
}