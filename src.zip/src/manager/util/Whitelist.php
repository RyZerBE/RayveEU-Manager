<?php

declare(strict_types=1);

namespace manager\util;

use manager\Manager;

class Whitelist{
    private array $whitelisted = [];
    private bool $enabled = true;

    public function __construct(){
        if(is_file(Manager::getBasePath()."whitelist.yml")) {
            $data = yaml_parse_file(Manager::getBasePath()."whitelist.yml");
            $this->enabled = $data["enabled"];
            $this->whitelisted = $data["whitelisted"];
        }
    }

    public function save(): void {
        file_put_contents(Manager::getBasePath()."whitelist.yml", yaml_emit([
            "enabled" => $this->enabled,
            "whitelisted" => $this->whitelisted,
        ]));
    }

    public function isEnabled(): bool{
        return $this->enabled;
    }

    public function setEnabled(bool $enabled): void{
        $this->enabled = $enabled;
    }

    public function isWhitelisted(string $name): bool {
        if(!$this->isEnabled()) {
            return true;
        }
        return in_array($name, $this->whitelisted, true);
    }

    public function addToWhitelist(string $name): void {
        if(!$this->isWhitelisted($name)) {
            $this->whitelisted[] = $name;
        }
    }

    public function removeFromWhitelist(string $name): void {
        if($this->isWhitelisted($name)) {
            unset($this->whitelisted[array_search($name, $this->whitelisted, true)]);
        }
    }
}