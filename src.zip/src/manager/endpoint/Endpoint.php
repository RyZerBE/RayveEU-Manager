<?php

declare(strict_types=1);

namespace manager\endpoint;

use manager\thread\Thread;
use manager\util\Logger;
use ThreadedArray;

abstract class Endpoint extends Thread{
    public function __construct(
        protected string $address,
        protected int $port,
    ){}

    /**
     * @return Path[]
     */
    abstract protected function getPaths(): array;

    public function onRun(): void{
        while($this->isRunning()) {
            try {
                $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                $bind = @socket_bind($socket, $this->address, $this->port);
                if($bind === false){
                    @socket_close($socket);

                    sleep(2);
                    continue;
                }
                socket_set_nonblock($socket);
                socket_listen($socket);
                break;
            } catch(\Exception $exception) {
            }
        }
        Logger::info("Successfully started endpoint.");

        $paths = [];
        foreach($this->getPaths() as $path) {
            $paths[$path->getPath()] = $path;
        }

        while($this->isRunning()) {
            $limit = 50;
            while($connection = @socket_accept($socket)) {
                if(--$limit < 0) {
                    break;
                }
                try {
                    socket_set_nonblock($connection);
                    socket_recvfrom($connection, $buffer,65535, 0, $address, $port);
                    if(is_string($buffer)) {
                        $result = "Unknown request";
                        if(str_starts_with($buffer, "GET")) {
                            $path = explode(" ", $buffer)[1];

                            $parts = explode("/", $path);
                            $key = array_pop($parts);
                            $path = implode("/", $parts);
                            if(isset($paths[$path])) {
                                $closure = $paths[$path]->getHandler();
                                $result = ($closure)($key) ?? "No response";
                            } else {
                                $result = $this->handleEmptyPath($path);
                            }
                        }
                        socket_write($connection, $result);
                    }
                    socket_close($connection);
                } catch(\Exception $exception) {
                }
            }
            usleep(300000);
        }
        socket_close($socket);
    }

    protected function handleEmptyPath(string $path): string {
        return "Unknown path";
    }
}