<?php

declare(strict_types=1);

namespace manager\endpoint;

use Closure;

class Path{
    public function __construct(
        private string $path,
        private Closure $handler,
    ){}

    public function getPath(): string{
        return $this->path;
    }

    public function getHandler(): Closure{
        return $this->handler;
    }
}