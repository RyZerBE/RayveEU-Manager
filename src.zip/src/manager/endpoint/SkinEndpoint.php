<?php

declare(strict_types=1);

namespace manager\endpoint;

use lookup\Network;

class SkinEndpoint extends Endpoint{
    protected function getPaths(): array{
        return [
            new Path("/minime", function(string $xboxId): ?string {
                $skinFile = Network::ROOT_PATH."Data/Skins/".$xboxId."_minime.png";
                if(!is_file($skinFile)) {
                    $skinFile = Network::ROOT_PATH."Source/skins/hylope.png";
                }

                $content = file_get_contents($skinFile);
                $headers = "HTTP/1.1 200 OK\r\n";
                $headers .= "Content-Type: image/png\r\n";
                $headers .= "Content-Length: " . strlen($content) . "\r\n";
                $headers .= "Connection: close\r\n\r\n";
                $headers .= $content;

                return $headers;
            }),
            new Path("/skin", function(string $xboxId): ?string {
                $skinFile = Network::ROOT_PATH."Data/Skins/".$xboxId.".png";
                if(!is_file($skinFile)) {
                    $skinFile = Network::ROOT_PATH."Source/skins/hylope.png";
                }

                $content = file_get_contents($skinFile);
                $headers = "HTTP/1.1 200 OK\r\n";
                $headers .= "Content-Type: image/png\r\n";
                $headers .= "Content-Length: " . strlen($content) . "\r\n";
                $headers .= "Connection: close\r\n\r\n";
                $headers .= $content;

                return $headers;
            }),
        ];
    }
}