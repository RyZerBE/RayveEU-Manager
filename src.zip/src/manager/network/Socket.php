<?php

declare(strict_types=1);

namespace manager\network;

use manager\Manager;
use manager\network\connection\Connection;
use manager\network\packet\Packet;
use manager\registry\PacketRegistry;
use manager\server\ServerManager;
use manager\thread\Thread;
use manager\util\Logger;
use packet\NoPacketDebug;
use packet\PacketIdentifier;
use packet\PacketManager;
use function socket_bind;
use function socket_close;
use function socket_create;
use function socket_listen;
use function socket_set_nonblock;

class Socket extends Thread {
    private const PHASE_VERIFY_LOGIN = 0;
    private const PHASE_WAITING_FOR_VERIFY = 1;
    private const PHASE_WAITING_FOR_FINISH = 2;

    public \ThreadedArray $incomingPackets;
    public \ThreadedArray $outgoingPackets;

    public function __construct(
        protected string $address,
        protected int $port
    ){}

    public function onRun(): void{
        $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        $bind = socket_bind($socket, $this->address, $this->port);
        if($bind === false){
            @socket_close($socket);
            Logger::error("Could not bind socket. Something else is running on ".$this->address.":".$this->port.".");
            return;
        }
        socket_set_nonblock($socket);
        socket_listen($socket);

        new PacketRegistry();

        /** @var Connection[] $connections */
        $connections = [];
        /** @var Connection[] $verified */
        $verified = [];

        $nextKeepAliveBuffer = time() + 10;

        $outgoingPackets = [];
        while($this->isRunning()) {
            $microtime = microtime(true);

            while($this->outgoingPackets->count() !== 0){
                $buffer = igbinary_unserialize($this->outgoingPackets->shift());
                $data = PacketManager::getInstance()->decodeBuffer($buffer);
                if(!isset($data["uniqueID"])) {
                    continue;
                }
                $outgoingPackets[$data["uniqueID"]][] = $buffer;
            }

            $connection = @socket_accept($socket);
            if($connection !== false) {
                socket_set_nonblock($connection);
                $connections[] = new Connection($connection);
            }

            foreach($connections as $key => $connection) {
                if($connection->hasLoginExpired()) {
                    unset($connections[$key]);
                    @socket_close($connection->socket);
                    continue;
                }
                switch($connection->loginPhase) {
                    case self::PHASE_VERIFY_LOGIN: {
                        if(socket_recvfrom($connection->socket, $buffer, 65535, 0, $address, $port) === false) {
                            break;
                        }
                        $packet = PacketManager::getInstance()->decodeBuffer($buffer);
                        if($packet === null || !isset($packet["uniqueID"])) {
                            unset($connections[$key]);
                            @socket_close($connection->socket);
                            break;
                        }
                        $connection->uniqueID = $packet["uniqueID"];
                        $this->submitIncomingPacket($buffer);
                        $connection->loginPhase = self::PHASE_WAITING_FOR_VERIFY;
                        break;
                    }
                    case self::PHASE_WAITING_FOR_VERIFY: {
                        if(!isset($outgoingPackets[$connection->uniqueID])) {
                            break;
                        }
                        $buffer = array_shift($outgoingPackets[$connection->uniqueID]);
                        socket_write($connection->socket, $buffer);
                        $connection->loginPhase = self::PHASE_WAITING_FOR_FINISH;
                        break;
                    }
                    case self::PHASE_WAITING_FOR_FINISH: {
                        if(socket_recvfrom($connection->socket, $buffer, 65535, 0, $address, $port) === false) {
                            break;
                        }
                        $packet = PacketManager::getInstance()->decodeBuffer($buffer);
                        if($packet === null || $packet["packet"] !== PacketIdentifier::FINISH_LOGIN_PACKET) {
                            unset($connections[$key]);
                            @socket_close($connection->socket);
                            break;
                        }
                        $this->submitIncomingPacket($buffer);
                        $connection->loginPhase = -1;

                        unset($connections[$key]);
                        $verified[$key] = $connection;
                        break;
                    }
                }
            }

            $keepAliveBuffer = time() >= $nextKeepAliveBuffer;
            if($keepAliveBuffer) {
                $nextKeepAliveBuffer = time() + 30;
            }
            foreach($verified as $key => $connection) {
                $buffer = null;
                socket_recvfrom($connection->socket, $buffer, 65535, 0, $address, $port);
                if(!empty($buffer)) {
                    foreach(explode("\r", $buffer) as $buf) {
                        $packet = PacketManager::getInstance()->decodeBuffer($buf);
                        if($packet === null) {
                            continue;
                        }
                        if($packet["packet"] === PacketIdentifier::SERVER_DISCONNECT_PACKET) {
                            @socket_close($connection->socket);
                            unset($verified[$key]);
                        }
                        $this->submitIncomingPacket($buf);
                    }
                }

                if($keepAliveBuffer) {
                    $outgoingPackets[$connection->uniqueID][] = "Bleib am Leben mein Sohn :c";
                }

                if(isset($outgoingPackets[$connection->uniqueID])) {
                    $buffer = "\r".implode("\r", array_values($outgoingPackets[$connection->uniqueID]));
                    if(@socket_write($connection->socket, $buffer) === false) {
                        @socket_close($connection->socket);
                        unset($verified[$key]);
                    }
                }
            }
            $outgoingPackets = [];

            if($keepAliveBuffer) {
                gc_enable();
                gc_collect_cycles();
                gc_mem_caches();
            }

            $sleep = (1000000 / Manager::TICKS_PER_SECOND) - ((microtime(true) - $microtime) * 1000000);
            if($sleep < 0) {
                $sleep = 0;
            }
            usleep((int)$sleep);
        }

        foreach(array_merge($verified, $connections) as $connection) {
            @socket_read($connection->socket, 65535);
            @socket_close($connection->socket);
        }
        socket_shutdown($socket);
        socket_close($socket);
    }

    public function submitOutgoingPacket($packet) : void{
        $this->outgoingPackets[] = igbinary_serialize($packet);
    }

    public function submitIncomingPacket($packet) : void{
        $this->incomingPackets[] = igbinary_serialize($packet);
    }
    
    public function checkProgressUpdates(): void{
        while($this->incomingPackets->count() !== 0){
            $buffer = igbinary_unserialize($this->incomingPackets->shift());
            $packet = PacketManager::getInstance()->handleBuffer($buffer, false);
            if($packet instanceof Packet) {
                if(!$packet instanceof NoPacketDebug) {
                    $packet->logIncomingPacket($packet);
                }
                $packet->handle($packet);
                ServerManager::getInstance()->getServerByUniqueID($packet->uniqueID)?->resetTimeout();
            }
        }
    }
}