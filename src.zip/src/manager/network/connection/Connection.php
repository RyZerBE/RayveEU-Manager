<?php

declare(strict_types=1);

namespace manager\network\connection;

use Socket;

class Connection {
    public int $loginTime;

    public function __construct(
        public Socket $socket,
        public ?string $uniqueID = null,
        public bool $login = false,
        public int $loginPhase = 0
    ){
        $this->loginTime = time();
    }

    public function hasLoginExpired(): bool {
        return time() > ($this->loginTime + 80);
    }
}