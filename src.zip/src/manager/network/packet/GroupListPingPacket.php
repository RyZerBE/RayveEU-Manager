<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\server\group\Group;
use manager\server\group\GroupManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class GroupListPingPacket extends Packet{
    public function getIdentifier(): int{
        return PacketIdentifier::GROUP_LIST_PING_PACKET;
    }

    public function handle(BasePacket $packet): void{
        $pk = new GroupListPongPacket();
        $pk->groups = array_map(function(Group $group): string {
            return $group->getFileName();
        }, GroupManager::getInstance()->getGroups());
        $packet->respond($pk);
    }
}