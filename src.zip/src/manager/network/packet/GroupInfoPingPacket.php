<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\server\group\GroupManager;
use manager\server\ServerManager;
use manager\util\Logger;
use packet\BasePacket;
use packet\PacketIdentifier;

class GroupInfoPingPacket extends Packet {
    public string $group;

    public function getIdentifier(): int{
        return PacketIdentifier::GROUP_INFO_PING_PACKET;
    }

    /**
     * @param GroupInfoPingPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $group = GroupManager::getInstance()->getGroup($packet->group);
        if($group === null) {
            Logger::warning("Could not find group ".$packet->group." in ".__FILE__."#".__LINE__);
            return;
        }
        $pk = new GroupInfoPongPacket();
        $pk->default = $group->isDefault();
        $pk->gameServer = $group->isGameServer();
        $pk->minServer = $group->getMinServer();
        $servers = [];
        foreach(ServerManager::getInstance()->getServersByGroup($group) as $server) {
            $servers[$server->getId()] = $server->asArray();
        }
        ksort($servers);
        $pk->servers = $servers;
        $packet->respond($pk);
    }
}