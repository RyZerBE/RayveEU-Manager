<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\server\group\GroupManager;
use manager\server\Server;
use manager\server\ServerManager;
use manager\util\Logger;
use packet\BasePacket;
use packet\PacketIdentifier;

class CreateReplayServerPacket extends Packet{
    public string $replayName;

    public function getIdentifier(): int{
        return PacketIdentifier::CREATE_REPLAY_SERVER_PACKET;
    }

    /**
     * @param CreateReplayServerPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $group = GroupManager::getInstance()->getGroup("Replay");
        if($group === null) {
            return;
        }
        $id = $group->getUsableId();
        $port = ServerManager::getInstance()->getUsablePort();

        $group->blockId($id);

        $server = new Server($group, $id, $port);
        $server->setCustom(true);
        $server->queueStartup();
        ServerManager::getInstance()->registerServer($server);

        $server->setWhenOnline(function() use ($packet, $server): void {
            Logger::debug("Game server was created successfully.");

            $pk = new CreateServerPongPacket();
            $pk->name = $server->getName();
            $packet->respond($pk);

            $server->sendPacket(InitializeReplayPacket::make($packet->replayName));
        });
    }
}