<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PlayerTransferPacket extends Packet{
    public string $player;
    public string $server;

    public function getIdentifier(): int{
        return PacketIdentifier::PLAYER_TRANSFER_PACKET;
    }

    /**
     * @param PlayerTransferPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $session = PlayerSessionManager::getSessionByXboxId($packet->player);
        if($session === null) {
            return;
        }
        $session->transfer($packet->server);
    }
}