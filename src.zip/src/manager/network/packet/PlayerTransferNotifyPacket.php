<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class PlayerTransferNotifyPacket extends Packet{
    public string $player;
    public string $server;

    public function getIdentifier(): int{
        return PacketIdentifier::PLAYER_TRANSFER_NOTIFY_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }
}