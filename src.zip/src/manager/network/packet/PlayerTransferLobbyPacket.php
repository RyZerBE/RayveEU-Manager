<?php

declare(strict_types=1);

namespace manager\network\packet;

use lookup\GroupIds;
use manager\player\PlayerSessionManager;
use manager\server\group\GroupManager;
use manager\server\group\type\LobbyGroup;
use manager\server\ServerManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PlayerTransferLobbyPacket extends Packet{
    public string $xboxId;

    public function getIdentifier(): int{
        return PacketIdentifier::PLAYER_TRANSFER_LOBBY_PACKET;
    }

    /**
     * @param self $packet
     */
    public function handle(BasePacket $packet): void{
        $session = PlayerSessionManager::getSessionByXboxId($packet->xboxId);
        if($session === null) {
            return;
        }
        $servers = [];
        foreach(ServerManager::getInstance()->getServersByGroup(GroupManager::getInstance()->getGroup(GroupIds::LOBBY)) as $server) {
            $servers[$server->getName()] = $server->getStatus()->onlinePlayers;
        }
        if(count($servers) <= 0) {
            $session->sendTranslatedMessage("message.error");
            return;
        }
        asort($servers);
        $servers = array_keys($servers);
        $server = array_shift($servers);
        $session->transfer($server);
    }
}