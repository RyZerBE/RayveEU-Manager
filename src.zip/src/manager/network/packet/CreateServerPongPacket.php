<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class CreateServerPongPacket extends Packet{
    public string $name;

    public function getIdentifier(): int{
        return PacketIdentifier::CREATE_SERVER_PONG_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }
}