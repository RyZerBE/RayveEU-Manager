<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class GroupInfoPongPacket extends Packet {
    public int $minServer;
    public bool $default;
    public bool $gameServer;
    public array $servers;

    public function getIdentifier(): int{
        return PacketIdentifier::GROUP_INFO_PONG_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }
}