<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\Manager;
use manager\player\PlayerSessionManager;
use manager\task\TaskManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PlayerCheckOnlineStatusPacket extends Packet {
    public string $xboxId;

    public function getIdentifier(): int{
        return PacketIdentifier::PLAYER_CHECK_ONLINE_STATUS_PACKET;
    }

    /**
     * @param PlayerCheckOnlineStatusPacket $packet
     */
    public function handle(BasePacket $packet): void{
        TaskManager::getInstance()->submitClosure(Manager::TICKS_PER_SECOND * 2, function() use ($packet): void {
            PlayerSessionManager::getSessionByXboxId($packet->xboxId)?->checkOnlineState();
        });
    }
}