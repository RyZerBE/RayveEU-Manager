<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\server\ServerManager;
use manager\util\Logger;
use packet\BasePacket;
use packet\NoPacketDebug;
use packet\PacketIdentifier;

class ServerStatusPacket extends Packet implements NoPacketDebug {
    public float $tpsAverage;
    public float $tickUsageAverage;

    public int $onlinePlayers;
    public int $maxOnlinePlayers;

    public float $packetDelay;

    public function getIdentifier(): int{
        return PacketIdentifier::SERVER_STATUS_PACKET;
    }

    /**
     * @param ServerStatusPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $server = ServerManager::getInstance()->getServerByUniqueID($packet->uniqueID);
        if($server === null) {
            return;
        }
        $status = $server->getStatus();
        $status->tpsAverage = $packet->tpsAverage;
        $status->tickUsageAverage = $packet->tickUsageAverage;
        $status->onlinePlayers = $packet->onlinePlayers;
        $status->maxOnlinePlayers = $packet->maxOnlinePlayers;
        $status->packetDelay = round(microtime(true) - $packet->packetDelay, 5);

        if(!$server->online) {
            Logger::info("Server ".$server->getName()." is now online.");
            $server->getGroup()->resetCrashes();
            $server->online = true;
            $closure = $server->whenOnline;
            if($closure !== null) {
                ($closure)($server);
            }
            $server->finishStartup();

            $settings = $server->getSettings();
            if(count($settings) > 0) {
                $string = "";
                foreach($settings as $key => $value) {
                    if($string !== "") {
                        $string .= "; ";
                    }
                    $string .= $key.": ".$value;
                }
                Logger::info("Settings -> ".$string);
            }
        }
    }
}