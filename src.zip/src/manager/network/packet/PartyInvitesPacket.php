<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PartyInvitesPacket extends Packet{
    public string $xboxId;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_INVITES_PACKET;
    }

    /**
     * @param PartyInvitesPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $player = PlayerSessionManager::getSessionByXboxId($packet->xboxId);
        if($player === null) {
            return;
        }
        $packet->respond(PartyListPongPacket::make($player->getPartyInvites()));
    }
}