<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\server\ServerManager;
use manager\util\Logger;
use packet\BasePacket;
use packet\PacketIdentifier;

class FinishLoginPacket extends Packet {
    public function getIdentifier(): int{
        return PacketIdentifier::FINISH_LOGIN_PACKET;
    }

    /**
     * @param Packet $packet
     */
    public function handle(BasePacket $packet): void{
        Logger::debug(ServerManager::getInstance()->getServerByUniqueID($packet->uniqueID)?->getName()." successfully logged in.");
    }
}