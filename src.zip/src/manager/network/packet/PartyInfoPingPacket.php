<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\party\PartyManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PartyInfoPingPacket extends Packet {
    public string $xboxId;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_INFO_PING_PACKET;
    }

    public function handle(BasePacket $packet): void{
        $packet->respond(PartyInfoPacket::make(PartyManager::getPartyByPlayer($this->xboxId)));
    }
}