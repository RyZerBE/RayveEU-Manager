<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\server\ServerManager;
use manager\util\Logger;
use packet\BasePacket;
use packet\PacketIdentifier;

class ServerStopPacket extends Packet{
    public string $server;

    public function getIdentifier(): int{
        return PacketIdentifier::SERVER_STOP_PACKET;
    }

    public function handle(BasePacket $packet): void{
        $server = ServerManager::getInstance()->getServerByName($packet->server);
        if($server !== null) {
            Logger::debug($server->getName().": Received stop packet.");
            $server->shutdown();
            $packet->respond(new EmptyPongPacket());
        }
    }
}