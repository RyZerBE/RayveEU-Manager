<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class FriendRequestListPongPacket extends Packet{
    public array $requests;

    public function getIdentifier(): int{
        return PacketIdentifier::FRIEND_REQUEST_LIST_PONG_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }
}