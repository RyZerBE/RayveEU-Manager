<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\party\PartyManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PartyDeletePacket extends Packet {
    public int $party;

    public function getIdentifier(): int {
        return PacketIdentifier::PARTY_DELETE_PACKET;
    }

    /**
     * @param PartyDeletePacket $packet
     */
    public function handle(BasePacket $packet): void {
        $party = PartyManager::getPartyById($packet->party);
        if($party === null) {
            return;
        }
        PartyManager::deleteParty($party);
        $packet->respond(new EmptyPongPacket());
    }
}