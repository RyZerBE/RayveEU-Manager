<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\party\PartyManager;
use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PartySetMemberRolePacket extends Packet{
    public string $xboxId;
    public int $party;
    public int $role;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_SET_MEMBER_ROLE_PACKET;
    }

    /**
     * @param PartySetMemberRolePacket $packet
     */
    public function handle(BasePacket $packet): void{
        $player = PlayerSessionManager::getSessionByXboxId($packet->xboxId);
        if($player === null) {
            return;
        }
        $party = PartyManager::getPartyById($packet->party);
        if($party === null) {
            return;
        }
        PartyManager::setMemberRole($party, $player, $packet->role);
        $packet->respond(new EmptyPongPacket());
    }
}