<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class SendTranslationMessagePacket extends Packet {
    public string $target;
    public string $key;
    public array $parameter;
    public ?string $prefix;

    public function getIdentifier(): int{
        return PacketIdentifier::SEND_TRANSLATION_MESSAGE_PACKET;
    }

    /**
     * @param SendTranslationMessagePacket $packet
     */
    public function handle(BasePacket $packet): void{
        if(strtoupper($packet->target) === "ALL") {
            foreach(PlayerSessionManager::getSessions() as $session) {
                $session->sendTranslatedMessage($packet->key, $packet->parameter, $packet->prefix);
            }
            return;
        }
        PlayerSessionManager::getSessionByXboxId($packet->target)?->sendTranslatedMessage($packet->key, $packet->parameter, $packet->prefix);
    }
}