<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class EmptyPingPacket extends Packet {
    public function getIdentifier(): int{
        return PacketIdentifier::EMPTY_PING_PACKET;
    }

    public function handle(BasePacket $packet): void{
        $packet->respond(new EmptyPongPacket());
    }
}