<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\party\PartyManager;
use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PartyMemberAddPacket extends Packet {
    public int $party;
    public string $xboxId;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_MEMBER_ADD_PACKET;
    }

    /**
     * @param PartyMemberAddPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $player = PlayerSessionManager::getSessionByXboxId($packet->xboxId);
        if($player === null) {
            return;
        }
        $party = PartyManager::getPartyById($packet->party);
        if($party === null) {
            $player->sendTranslatedMessage("message.party_does_not_exist");
            return;
        }
        PartyManager::addMember($party, $player);
        $packet->respond(new EmptyPongPacket());
    }
}