<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\party\PartyManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PartyCreatePacket extends Packet {
    public string $xboxId;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_CREATE_PACKET;
    }

    /**
     * @param PartyCreatePacket $packet
     */
    public function handle(BasePacket $packet): void{
        $party = PartyManager::createParty($packet->xboxId);
        $packet->respond(PartyInfoPacket::make($party));
    }
}