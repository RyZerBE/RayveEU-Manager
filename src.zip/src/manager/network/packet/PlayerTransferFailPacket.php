<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class PlayerTransferFailPacket extends Packet{
    public string $xboxId;

    public function getIdentifier(): int{
        return PacketIdentifier::PLAYER_TRANSFER_FAIL_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }
}