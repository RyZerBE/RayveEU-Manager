<?php

declare(strict_types=1);

namespace manager\network\packet;

use lookup\Setting;
use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class FriendRequestSendPacket extends Packet{
    public string $sender;
    public string $target;

    public function getIdentifier(): int{
        return PacketIdentifier::FRIEND_REQUEST_SEND_PACKET;
    }

    /**
     * @param self $packet
     */
    public function handle(BasePacket $packet): void{
        $sender = PlayerSessionManager::getSessionByXboxId($packet->sender);
        if($sender === null) {
            return;
        }
        $target = PlayerSessionManager::getSessionByXboxId($packet->target);
        if($target === null) {
            $sender->sendTranslatedMessage("message.player_offline");
            return;
        }
        if($target->getName() === $sender->getName()) {
            $sender->sendTranslatedMessage("message.weird_friendship");
            return;
        }
        if($target->getFriendManager()->getFriend($sender->getXboxId()) !== null) {
            $sender->sendTranslatedMessage("message.already_friends", [
                "player" => $target->getDisplayName()
            ]);
            return;
        }
        if($target->getFriendManager()->hasFriendRequest($sender->getXboxId())) {
            $sender->sendTranslatedMessage("message.already_sent_friend_requests", [
                "player" => $target->getDisplayName()
            ]);
            return;
        }
        if(!$target->getSettings()->getBool(Setting::ALLOW_FRIEND_REQUESTS)) {
            $sender->sendTranslatedMessage("message.does_not_accept_friend_requests", [
                "player" => $target->getDisplayName()
            ]);
            return;
        }
        $target->getFriendManager()->addFriendRequest($sender->getXboxId());

        $target->sendTranslatedMessage("message.friend_request_received", [
            "player" => $sender->getDisplayName()
        ]);
        $sender->sendTranslatedMessage("message.friend_request_sent", [
            "player" => $target->getDisplayName()
        ]);
        $packet->respond(new EmptyPongPacket());
    }
}