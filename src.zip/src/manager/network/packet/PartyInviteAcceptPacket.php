<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\party\PartyManager;
use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PartyInviteAcceptPacket extends Packet{
    public string $xboxId;
    public int $party;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_INVITE_ACCEPT_PACKET;
    }

    /**
     * @param PartyInviteAcceptPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $player = PlayerSessionManager::getSessionByXboxId($packet->xboxId);
        if($player === null) {
            return;
        }
        $player->removePartyInvite($packet->party);

        $party = PartyManager::getPartyById($packet->party);
        if($party === null) {
            $player->sendTranslatedMessage("message.party_does_not_exist");
            return;
        }
        if($party->isFull()) {
            $player->sendTranslatedMessage("message.party_full");
            return;
        }
        PartyManager::addMember($party, $player);
        $packet->respond(new EmptyPongPacket());
    }
}