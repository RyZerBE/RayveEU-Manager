<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\server\Server;
use packet\BasePacket;
use packet\PacketIdentifier;

class InitializeReplayPacket extends Packet{
    public string $replayName;

    public function getIdentifier(): int{
        return PacketIdentifier::INITIALIZE_REPLAY_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }

    public static function make(string $replayName): self {
        $pk = new self();
        $pk->replayName = $replayName;
        return $pk;
    }
}