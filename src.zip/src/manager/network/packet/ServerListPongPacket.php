<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class ServerListPongPacket extends Packet{
    public array $servers;

    public function getIdentifier(): int{
        return PacketIdentifier::SERVER_LIST_PONG_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }
}