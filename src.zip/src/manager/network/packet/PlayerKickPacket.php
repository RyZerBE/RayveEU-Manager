<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSession;
use packet\BasePacket;
use packet\PacketIdentifier;

class PlayerKickPacket extends Packet{
    public string $xboxId;
    public string $reason;

    public static function make(PlayerSession $session, string $reason): self {
        $pk = new self();
        $pk->xboxId = $session->getXboxId();
        $pk->reason = $reason;
        return $pk;
    }

    public function getIdentifier(): int{
        return PacketIdentifier::PLAYER_KICK_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }
}