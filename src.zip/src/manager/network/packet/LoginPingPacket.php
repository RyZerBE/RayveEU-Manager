<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\Manager;
use manager\server\ServerManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class LoginPingPacket extends Packet {
    public string $password;

    public function getIdentifier(): int{
        return PacketIdentifier::LOGIN_PING_PACKET;
    }

    /**
     * @param LoginPingPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $server = ServerManager::getInstance()->getServerByUniqueID($packet->uniqueID);
        $password = Manager::getInstance()->getPassword();
        if($server === null || $password !== $packet->password) {
            return;
        }
        $server->sendPacket(new AcceptLoginPacket());
    }
}