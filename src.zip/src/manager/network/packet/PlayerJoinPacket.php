<?php

declare(strict_types=1);

namespace manager\network\packet;

use lookup\Setting;
use manager\Manager;
use manager\player\PlayerSession;
use manager\player\PlayerSessionManager;
use manager\server\group\type\LobbyGroup;
use manager\server\ServerManager;
use manager\util\Logger;
use packet\BasePacket;
use packet\PacketIdentifier;

class PlayerJoinPacket extends Packet {
    public string $xboxId;
    public string $name;
    public string $playFabId;
    public string $clientRandomId;

    public function getIdentifier(): int{
        return PacketIdentifier::PLAYER_JOIN_PACKET;
    }

    /**
     * @param PlayerJoinPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $player = PlayerSessionManager::getSessionByXboxId($packet->xboxId);
        $joined = $player === null;
        if($player === null) {
            $player = PlayerSessionManager::addSession(new PlayerSession($packet->xboxId, $packet->name, $this->playFabId, $this->clientRandomId));
        }
        $player->setServer(ServerManager::getInstance()->getServerByUniqueID($packet->uniqueID)?->getName());
        if(!Manager::getInstance()->getWhitelist()->isWhitelisted($player->getName())) {
            $player->sendPacket(PlayerKickPacket::make($player, $player->translate("§cYou are not whitelisted!")));
            return;
        }
        $player->initialize(function() use ($player, $packet, $joined): void {
            if($joined) {
                Logger::info($player->getName()." joined the network.");

                foreach($player->getFriendManager()->getFriends() as $friend) {
                    $friendSession = PlayerSessionManager::getSessionByXboxId($friend->getXboxId());
                    if($friendSession === null) {
                        continue;
                    }
                    $joinMessage = $friendSession->getSettings()->getInt(Setting::SHOW_FRIEND_JOIN_MESSAGE);
                    if($joinMessage === 2 || (!$friend->isClose() && $joinMessage === 1)) {
                        continue;
                    }
                    $friendSession->sendTranslatedMessage("message.friend_online", [
                        "player" => $player->getName()
                    ]);
                }
            }
            $pk = new PlayerVerifyPacket();
            $pk->xboxId = $player->getXboxId();
            $packet?->respond($pk);
        });
    }
}