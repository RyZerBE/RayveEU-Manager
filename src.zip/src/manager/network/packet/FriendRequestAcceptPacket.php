<?php

declare(strict_types=1);

namespace manager\network\packet;

use lookup\object\Friend;
use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class FriendRequestAcceptPacket extends Packet{
    public string $player;
    public string $sender;

    public function getIdentifier(): int{
        return PacketIdentifier::FRIEND_REQUEST_ACCEPT_PACKET;
    }

    /**
     * @param FriendRequestAcceptPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $player = PlayerSessionManager::getSessionByXboxId($packet->player);
        if($player === null) {
            return;
        }
        $sender = PlayerSessionManager::getSessionByXboxId($packet->sender);
        if($sender === null || !$player->getFriendManager()->hasFriendRequest($packet->sender)) {
            $player->sendTranslatedMessage("message.friend_request_not_found");
            return;
        }
        $player->getFriendManager()->removeFriendRequest($packet->sender);

        $player->getFriendManager()->addFriend(new Friend($sender->getXboxId(), $sender->getName(), $sender->getDisplayName(), true, false), true);
        $sender->getFriendManager()->addFriend(new Friend($player->getXboxId(), $player->getName(), $player->getDisplayName(), true, false));

        $sender->sendTranslatedMessage("message.friend_request_accepted_by_player", [
            "player" => $player->getDisplayName()
        ]);
        $player->sendTranslatedMessage("message.friend_request_accepted_from_player", [
            "player" => $sender->getDisplayName()
        ]);
    }
}