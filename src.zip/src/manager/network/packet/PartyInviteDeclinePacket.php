<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PartyInviteDeclinePacket extends Packet{
    public string $xboxId;
    public int $party;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_INVITE_DECLINE_PACKET;
    }

    /**
     * @param PartyInviteAcceptPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $player = PlayerSessionManager::getSessionByXboxId($packet->xboxId);
        if($player === null) {
            return;
        }
        $player->removePartyInvite($packet->party);
        $player->sendTranslatedMessage("message.party_invite_declined");
        $packet->respond(new EmptyPongPacket());
    }
}