<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\server\ServerManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class ServerBlockPacket extends Packet{
    public bool $blocked;
    public string $server;

    public function getIdentifier(): int{
        return PacketIdentifier::SERVER_BLOCK_PACKET;
    }

    /**
     * @param ServerBlockPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $server = ServerManager::getInstance()->getServerByName($packet->server);
        if(!$server !== null) {
            $server->setBlocked($packet->blocked);
            $packet->respond(new EmptyPongPacket());
        }
    }
}