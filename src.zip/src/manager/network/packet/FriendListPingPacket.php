<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class FriendListPingPacket extends Packet{
    public string $xboxId;

    public function getIdentifier(): int{
        return PacketIdentifier::FRIEND_LIST_PING_PACKET;
    }

    public function handle(BasePacket $packet): void{
        $session = PlayerSessionManager::getSessionByXboxId($packet->xboxId);
        if($session === null) {
            return;
        }
        $friends = [];
        foreach($session->getFriendManager()->getFriends() as $friend) {
            $friends[] = $friend->asArray();
        }

        $pk = new FriendListPongPacket();
        $pk->friends = $friends;
        $packet->respond($pk);
    }
}