<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSessionManager;
use manager\server\ServerManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class ServerRejoinPacket extends Packet{
    public string $xboxId;

    public function getIdentifier(): int{
        return PacketIdentifier::SERVER_REJOIN_PACKET;
    }

    /**
     * @param self $packet
     */
    public function handle(BasePacket $packet): void{
        $session = PlayerSessionManager::getSessionByXboxId($packet->xboxId);
        if($session === null) {
            return;
        }
        foreach(ServerManager::getInstance()->getServers() as $server) {
            if($server->isInRejoinCache($session)) {
                $session->transfer($server->getName());
                return;
            }
        }
        $session->sendTranslatedMessage("message.no_server_for_rejoin_found");
    }
}