<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\server\ServerManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class ServerListPingPacket extends Packet{
    public function getIdentifier(): int{
        return PacketIdentifier::SERVER_LIST_PING_PACKET;
    }

    public function handle(BasePacket $packet): void{
        $pk = new ServerListPongPacket();
        foreach(ServerManager::getInstance()->getServers() as $server) {
            if(!$server->isOnline()) {
                continue;
            }
            $pk->servers[] = $server->asArray();
        }
        $packet->respond($pk);
    }
}