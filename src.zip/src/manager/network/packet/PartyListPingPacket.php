<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\party\PartyManager;
use packet\BasePacket;
use packet\PacketIdentifier;
use party\Party;

class PartyListPingPacket extends Packet {
    public bool $public;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_LIST_PING_PACKET;
    }

    /**
     * @param PartyListPingPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $packet->respond(PartyListPongPacket::make(array_filter(PartyManager::getParties(), function(Party $party) use ($packet): bool {
            if(!$packet->public) {
                return true;
            }
            return $party->isPublic();
        })));
    }
}