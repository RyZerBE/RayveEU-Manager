<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class PlayerSearchPongPacket extends Packet{
    public bool $found;
    public string $name;
    public string $xboxId;
    public string $server;

    public function getIdentifier(): int{
        return PacketIdentifier::PLAYER_SEARCH_PONG_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }
}