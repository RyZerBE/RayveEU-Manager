<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class GroupListPongPacket extends Packet{
    public array $groups;

    public function getIdentifier(): int{
        return PacketIdentifier::GROUP_LIST_PONG_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }
}