<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\server\ServerManager;
use manager\util\Logger;
use packet\BasePacket;
use packet\PacketIdentifier;

class ServerDisconnectPacket extends Packet {
    public const REASON_SERVER_SHUTDOWN = 0;
    public const REASON_MANAGER_SHUTDOWN = 1;

    public int $reason;

    public function getIdentifier(): int{
        return PacketIdentifier::SERVER_DISCONNECT_PACKET;
    }

    /**
     * @param Packet $packet
     */
    public function handle(BasePacket $packet): void{
        $server = ServerManager::getInstance()->getServerByUniqueID($packet->uniqueID);
        if($server !== null) {
            $server->shutdown();
            if($packet->reason === self::REASON_MANAGER_SHUTDOWN) {
                Logger::debug($server->getName().": Manager shutdown.");
            }
        }
    }
}