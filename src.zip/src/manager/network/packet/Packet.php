<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\Manager;
use manager\util\Logger;
use packet\BasePacket;
use packet\NoPacketDebug;
use packet\PacketManager;
use ReflectionClass;

abstract class Packet extends BasePacket {
    public string $uniqueID;

    /**
     * @param Packet $packet
     */
    public function respond(BasePacket $packet): void{
        $packet->uniqueID = $this->uniqueID;
        if(isset($this->requestID)) {
            $packet->requestID = $this->requestID;
        }
        $buffer = $packet->encode();
        if(!$packet instanceof NoPacketDebug){
            $this->logOutgoingPacket($packet);
        }
        Manager::getInstance()->getSocket()->submitOutgoingPacket($buffer);
    }

    public function send(): void {
        $buffer = $this->encode();
        $this->logOutgoingPacket($this);
        Manager::getInstance()->getSocket()->submitOutgoingPacket($buffer);
    }

    protected function logOutgoingPacket(Packet $packet): void {
        if(Logger::$showPacketContent) {
            $packetName = (new ReflectionClass(PacketManager::getInstance()->getPacket($packet->getIdentifier())))->getShortName();
            Logger::packet("Sending ".$packetName.implode("", $this->getPacketContent($packet)));
        } else {
            Logger::debug("Sending Packet: ".$packet->getIdentifier());
        }
    }

    public function logIncomingPacket(Packet $packet): void {
        if(Logger::$showPacketContent) {
            $packetName = (new ReflectionClass(PacketManager::getInstance()->getPacket($packet->getIdentifier())))->getShortName();
            Logger::packet("Received ".$packetName.implode("", $this->getPacketContent($packet)));
        } else {
            Logger::debug("Received Packet: ".$packet->getIdentifier());
        }
    }

    private function getPacketContent(Packet $packet): array {
        $content = [];
        $class = new ReflectionClass($packet);
        foreach($class->getProperties() as $property) {
            if(!$property->isInitialized($packet)) {
                continue;
            }
            $value = $property->getValue($packet);
            if(is_bool($value)) {
                $value = ($value ? "true" : "false");
            } elseif(is_array($value)) {
                $value = json_encode($value, JSON_THROW_ON_ERROR);
            } elseif(is_null($value)) {
                $value = "NULL";
            }
            $name = $property->getName();
            $content[$name] = "\n- ".$name.": ".$value;
        }
        unset($content["uniqueID"], $content["requestID"]);
        return array_values($content);
    }
}