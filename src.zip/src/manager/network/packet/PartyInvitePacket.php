<?php

declare(strict_types=1);

namespace manager\network\packet;

use lookup\Setting;
use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PartyInvitePacket extends Packet{
    public string $sender;
    public string $target;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_INVITE_PACKET;
    }

    /**
     * @param PartyInvitePacket $packet
     */
    public function handle(BasePacket $packet): void{
        $sender = PlayerSessionManager::getSessionByXboxId($packet->sender);
        if($sender === null) {
            return;
        }
        $party = $sender->getParty();
        if($party === null) {
            $sender->sendTranslatedMessage("message.not_in_party");
            return;
        }
        $target = PlayerSessionManager::getSessionByXboxId($packet->target) ?? PlayerSessionManager::getSessionByName($packet->target);
        if($target === null) {
            $sender->sendTranslatedMessage("message.player_offline");
            return;
        }
        if($target->getXboxId() === $sender->getXboxId()) {
            $sender->sendTranslatedMessage("message.cannot_invite_yourself");
            return;
        }
        $allowRequests = $target->getSettings()->getInt(Setting::ALLOW_PARTY_REQUESTS);
        if($allowRequests === 2) {
            $sender->sendTranslatedMessage("message.does_not_accept_party_invites");
            return;
        }

        //TODO: Validate if player can be invited when there are friends (First we need a friend system!)

        if($party->getMember($target->getXboxId()) !== null) {
            $sender->sendTranslatedMessage("message.already_in_same_party");
            return;
        }
        if($target->getParty() !== null) {
            $sender->sendTranslatedMessage("message.already_in_party");
            return;
        }
        if($party->isFull()) {
            $sender->sendTranslatedMessage("message.party_full");
            return;
        }
        if($target->hasPartyInvite($party)) {
            $sender->sendTranslatedMessage("message.already_invited_in_party");
            return;
        }
        $target->inviteToParty($party);
        $target->sendTranslatedMessage("message.party_invite_received", [
            "player" => $sender->getDisplayName()
        ]);
        $sender->sendTranslatedMessage("message.party_player_invited", [
            "player" => $target->getDisplayName()
        ]);
        $packet->respond(new EmptyPongPacket());
    }
}