<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;
use party\Party;

class PartyListPongPacket extends Packet {
    public array $parties;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_LIST_PONG_PACKET;
    }

    /**
     * @param Party[] $parties
     */
    public static function make(array $parties): PartyListPongPacket {
        $packet = new self();
        $packet->parties = array_map(function(Party $party): array {
            return $party->encode();
        }, $parties);
        return $packet;
    }

    public function handle(BasePacket $packet): void{
    }
}