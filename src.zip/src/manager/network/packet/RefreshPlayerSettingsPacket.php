<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class RefreshPlayerSettingsPacket extends Packet{
    public string $xboxId;

    public function getIdentifier(): int{
        return PacketIdentifier::REFRESH_PLAYER_SETTINGS_PACKET;
    }

    /**
     * @param RefreshPlayerSettingsPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $session = PlayerSessionManager::getSessionByXboxId($packet->xboxId);
        if($session === null) {
            return;
        }
        $session->refreshSettings(function() use ($packet): void {
            $packet->respond(new EmptyPongPacket());
        });
    }
}