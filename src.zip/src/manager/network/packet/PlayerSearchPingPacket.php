<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PlayerSearchPingPacket extends Packet{
    public string $search;

    public function getIdentifier(): int{
        return PacketIdentifier::PLAYER_SEARCH_PING_PACKET;
    }

    /**
     * @param PlayerSearchPingPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $session = PlayerSessionManager::getSessionByXboxId($packet->search) ?? PlayerSessionManager::getSessionByName($packet->search);
        if($session === null) {
            $name = strtolower($packet->search);
            $delta = PHP_INT_MAX;
            foreach(PlayerSessionManager::getSessions() as $player){
                if(stripos($player->getName(), $name) === 0){
                    $curDelta = strlen($player->getName()) - strlen($name);
                    if($curDelta < $delta){
                        $session = $player;
                        $delta = $curDelta;
                    }
                    if($curDelta === 0){
                        break;
                    }
                }
            }
        }

        $pk = new PlayerSearchPongPacket();
        if($session === null) {
            $pk->found = false;
        } else {
            $pk->found = true;
            $pk->server = $session->getServer();
            $pk->name = $session->getName();
            $pk->xboxId = $session->getXboxId();
        }
        $packet->respond($pk);
    }
}