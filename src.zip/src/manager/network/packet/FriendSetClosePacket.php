<?php

declare(strict_types=1);

namespace manager\network\packet;

use lookup\object\Friend;
use manager\player\PlayerSessionManager;
use manager\util\Logger;
use packet\BasePacket;
use packet\PacketIdentifier;

class FriendSetClosePacket extends Packet{
    public string $player;
    public string $friend;
    public bool $close;

    public function getIdentifier(): int{
        return PacketIdentifier::FRIEND_SET_CLOSE_PACKET;
    }

    /**
     * @param self $packet
     */
    public function handle(BasePacket $packet): void{
        $player = PlayerSessionManager::getSessionByXboxId($packet->player);
        if($player === null) {
            return;
        }
        $friend = $player->getFriendManager()->getFriend($packet->friend);
        if($friend === null) {
            Logger::error("Friend must not be null.");
            return;
        }
        $friend->setClose($packet->close);

        $packet->respond(new EmptyPongPacket());
    }
}