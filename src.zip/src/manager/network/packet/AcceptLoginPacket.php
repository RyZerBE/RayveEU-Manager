<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class AcceptLoginPacket extends Packet {
    public string $uniqueID;

    public function getIdentifier(): int{
        return PacketIdentifier::ACCEPT_LOGIN_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }
}