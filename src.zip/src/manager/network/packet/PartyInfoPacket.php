<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;
use party\Party;

class PartyInfoPacket extends Packet {
    public ?array $party;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_INFO_PACKET;
    }

    public static function make(?Party $party): PartyInfoPacket {
        $packet = new PartyInfoPacket();
        $packet->party = $party?->encode();
        return $packet;
    }

    public function handle(BasePacket $packet): void{
    }
}