<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\party\PartyManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PartyAccessStatusPacket extends Packet{
    public bool $public;
    public int $party;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_ACCESS_STATUS_PACKET;
    }

    /**
     * @param PartyAccessStatusPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $party = PartyManager::getPartyById($packet->party);
        if($party === null) {
            return;
        }
        $party->setPublic($packet->public);
        $packet->respond(new EmptyPongPacket());
    }
}