<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class SendMessagePacket extends Packet {
    public string $message;
    public string $target;

    public function getIdentifier(): int{
        return PacketIdentifier::SEND_MESSAGE_PACKET;
    }

    /**
     * @param SendMessagePacket $packet
     */
    public function handle(BasePacket $packet): void{
        if(strtoupper($packet->target) === "ALL") {
            foreach(PlayerSessionManager::getSessions() as $session) {
                $session->sendMessage($packet->message);
            }
            return;
        }
        PlayerSessionManager::getSessionByXboxId($packet->target)?->sendMessage($packet->message);
    }
}