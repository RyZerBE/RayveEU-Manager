<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class EmptyPongPacket extends Packet {
    public function getIdentifier(): int{
        return PacketIdentifier::EMPTY_PONG_PACKET;
    }

    public function handle(BasePacket $packet): void{}
}