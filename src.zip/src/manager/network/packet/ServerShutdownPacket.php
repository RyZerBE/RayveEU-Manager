<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class ServerShutdownPacket extends Packet {
    public function getIdentifier(): int{
        return PacketIdentifier::SERVER_SHUTDOWN_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }
}