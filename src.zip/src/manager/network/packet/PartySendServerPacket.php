<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\party\PartyManager;
use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class PartySendServerPacket extends Packet {
    public int $party;
    public string $server;

    public function getIdentifier(): int{
        return PacketIdentifier::PARTY_SEND_SERVER_PACKET;
    }

    /**
     * @param PartySendServerPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $party = PartyManager::getPartyById($packet->party);
        if($party === null) return;
        foreach($party->getMembers() as $member) {
            PlayerSessionManager::getSessionByXboxId($member->getXboxId())?->transfer($packet->server);
        }
    }
}