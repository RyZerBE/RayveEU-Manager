<?php

declare(strict_types=1);

namespace manager\network\packet;

use lookup\object\User;
use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class FriendRequestListPingPacket extends Packet{
    public string $xboxId;

    public function getIdentifier(): int{
        return PacketIdentifier::FRIEND_REQUEST_LIST_PING_PACKET;
    }

    public function handle(BasePacket $packet): void{
        $player = PlayerSessionManager::getSessionByXboxId($packet->xboxId);
        if($player === null) {
            return;
        }
        $requests = [];
        foreach($player->getFriendManager()->getFriendRequests() as $request) {
            $requestSession = PlayerSessionManager::getSessionByXboxId($request);
            if($requestSession === null) {
                continue;
            }
            $requests[] = (new User($request, $requestSession->getName(), $requestSession->getDisplayName(), true))->asArray();
        }

        $pk = new FriendRequestListPongPacket();
        $pk->requests = $requests;
        $packet->respond($pk);
    }
}