<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSessionManager;
use manager\task\AsyncPool;
use packet\BasePacket;
use packet\PacketIdentifier;
use restapi\endpoint\PlayerEndpoint;
use restapi\RestAPI;

class PlayerQuitPacket extends Packet {
    public string $xboxId;

    public function getIdentifier(): int{
        return PacketIdentifier::PLAYER_QUIT_PACKET;
    }

    /**
     * @param PlayerQuitPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $session = PlayerSessionManager::getSessionByXboxId($packet->xboxId);
        if($session === null) {
            return;
        }
        $xboxId = $session->getXboxId();
        AsyncPool::getInstance()->submitClosure(function() use ($xboxId): bool {
            return RestAPI::execute(["title" => "§r"], "player/".$xboxId."/title")["success"] ?? false;
        }, function(bool $online) use ($session): void {
            if($online) {
                return;
            }
            PlayerSessionManager::removeSession($session);
        });
    }
}