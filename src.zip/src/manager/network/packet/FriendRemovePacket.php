<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSessionManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class FriendRemovePacket extends Packet{
    public string $player;
    public string $friend;

    public function getIdentifier(): int{
        return PacketIdentifier::FRIEND_REMOVE_PACKET;
    }

    /**
     * @param self $packet
     */
    public function handle(BasePacket $packet): void{
        $player = PlayerSessionManager::getSessionByXboxId($packet->player);
        if($player === null) {
            return;
        }
        $friend = $player->getFriendManager()->getFriend($packet->friend);
        if($friend === null) {
            $player->sendTranslatedMessage("message.player_not_friend");
            return;
        }

        $player->getFriendManager()->removeFriend($friend, true);

        $player->sendTranslatedMessage("message.friend_removed", [
            "player" => $friend->getDisplayName()
        ]);

        $friendSession = PlayerSessionManager::getSessionByXboxId($friend->getXboxId());
        if($friendSession !== null) {
            $friendSession->sendTranslatedMessage("message.friendship_ended", ["player" => $player->getDisplayName()]);
            $friendSession->getFriendManager()->removeFriend($friendSession->getFriendManager()->getFriend($player->getXboxId()));
        }
    }
}