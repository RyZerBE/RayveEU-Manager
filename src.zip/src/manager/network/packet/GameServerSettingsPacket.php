<?php

declare(strict_types=1);

namespace manager\network\packet;

use packet\BasePacket;
use packet\PacketIdentifier;

class GameServerSettingsPacket extends Packet{
    public array $settings;

    public function getIdentifier(): int{
        return PacketIdentifier::GAME_SERVER_SETTINGS_PACKET;
    }

    public function handle(BasePacket $packet): void{
    }
}