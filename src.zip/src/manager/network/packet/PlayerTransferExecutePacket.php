<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\player\PlayerSessionManager;
use manager\server\ServerManager;
use manager\task\AsyncPool;
use packet\BasePacket;
use packet\PacketIdentifier;
use restapi\endpoint\PlayerEndpoint;

class PlayerTransferExecutePacket extends Packet{
    public string $player;
    public string $server;

    public function getIdentifier(): int{
        return PacketIdentifier::PLAYER_TRANSFER_EXECUTE_PACKET;
    }

    /**
     * @param PlayerTransferExecutePacket $packet
     */
    public function handle(BasePacket $packet): void{
        $session = PlayerSessionManager::getSessionByXboxId($packet->player);
        if($session === null) {
            return;
        }
        $server = ServerManager::getInstance()->getServerByName($packet->server);
        if($server === null) {
            $session->sendTranslatedMessage("message.transfer_failed_reason_server_offline");
        } else {
            $xboxId = $session->getXboxId();
            $name = $server->getName();
            AsyncPool::getInstance()->submitClosure(function() use ($xboxId, $name): void {
                PlayerEndpoint::transfer($xboxId, $name);
            }, function() use ($session): void {
                $session->transfer = false;
            });
        }
    }
}