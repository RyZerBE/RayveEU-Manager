<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\server\ServerManager;
use packet\BasePacket;
use packet\PacketIdentifier;

class ServerSyncRejoinCachePacket extends Packet{
    public array $players;

    public function getIdentifier(): int{
        return PacketIdentifier::SERVER_SYNC_REJOIN_CACHE_PACKET;
    }

    public function handle(BasePacket $packet): void{
        $server = ServerManager::getInstance()->getServerByUniqueID($packet->uniqueID);
        if($server === null) {
            return;
        }
        foreach($packet->players as $player) {
            $server->addToRejoinCache($player);
        }
    }
}