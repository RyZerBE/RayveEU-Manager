<?php

declare(strict_types=1);

namespace manager\network\packet;

use manager\server\group\GroupManager;
use manager\server\Server;
use manager\server\ServerManager;
use manager\util\Logger;
use packet\BasePacket;
use packet\PacketIdentifier;

class CreateGameServerPingPacket extends Packet{
    public string $group;
    public array $settings;

    public function getIdentifier(): int{
        return PacketIdentifier::CREATE_GAME_SERVER_PING_PACKET;
    }

    /**
     * @param CreateGameServerPingPacket $packet
     */
    public function handle(BasePacket $packet): void{
        $group = GroupManager::getInstance()->getGroup($packet->group);
        if($group === null) {
            return;
        }
        $id = $group->getUsableId();
        $port = ServerManager::getInstance()->getUsablePort();

        $group->blockId($id);

        $server = new Server($group, $id, $port);
        $server->setCustom(true);
        $server->setSettings($packet->settings);
        $server->queueStartup();
        ServerManager::getInstance()->registerServer($server);

        $server->setWhenOnline(function() use ($packet, $server): void {
            Logger::debug("Game server was created successfully.");

            $pk = new CreateServerPongPacket();
            $pk->name = $server->getName();
            $packet->respond($pk);
        });
    }
}