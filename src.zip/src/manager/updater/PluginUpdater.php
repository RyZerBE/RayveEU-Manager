<?php

declare(strict_types=1);

namespace manager\updater;

use manager\Manager;
use manager\server\group\GroupManager;
use manager\task\AsyncPool;
use manager\util\Logger;

class PluginUpdater{
    private static array $groupPlugins = [];

    public function __construct(){
        $this->updateGroupPlugins();
    }

    public function updateGroupPlugins(): void {
        self::$groupPlugins = [];
        foreach(GroupManager::getInstance()->getGroups() as $group) {
            $templatePluginsPath = Manager::getBasePath()."template_plugins/".$group->getFileName();
            foreach(scandir($templatePluginsPath) as $plugin) {
                $pluginPath = $templatePluginsPath."/".$plugin;
                if(is_file($pluginPath."/plugin.yml")) {
                    self::$groupPlugins[$group->getFileName()][$plugin] = -1;
                }
            }
        }
    }

    public function tick(int $tick): void {
        if($tick % 80 !== 0) {
            return;
        }
        $groupPlugins = self::$groupPlugins;
        AsyncPool::getInstance()->submitClosure(function() use ($groupPlugins): array {
            clearstatcache();

            $updates = [];

            self::getPluginModificationTime($updates);

            $groupUpdates = [];
            foreach($updates as $plugin => $time) {
                foreach($groupPlugins as $group => $plugins) {
                    foreach($plugins as $groupPlugin => $lastUpdate) {
                        if($plugin !== $groupPlugin) {
                            continue;
                        }
                        if($time > $lastUpdate) {
                            $groupPlugins[$group][$groupPlugin] = $time;

                            if(($lastUpdate !== -1) && !in_array($group, $groupUpdates, true)) {
                                $groupUpdates[] = $group;
                            }
                        }
                    }
                }
            }

            return [$groupPlugins, $groupUpdates];
        }, function(array $data): void {
            self::$groupPlugins = $data[0];
            foreach($data[1] as $group) {
                $group = GroupManager::getInstance()->getGroup($group);
                if($group !== null) {
                    if(!$group->requiresUpdate) {
                        Logger::debug("Scheduled update for group ".$group->getFileName().".");
                        $group->requiresUpdate = true;
                    }
                    $group->scheduledServerRestart = time() + 10;
                }
            }
        });
    }

    private static function getPluginModificationTime(array &$lastUpdates): void {
        $path = Manager::getBasePath()."../Source/plugins/";
        foreach(scandir($path) as $plugin) {
            if(is_file($path.$plugin."/plugin.yml")) {
                $time = 0;
                self::getLastModificationTime($path.$plugin."/", $time);
                $lastUpdates[$plugin] = $time;
            }
        }
    }

    private static function getLastModificationTime(string $directory, int &$time): void{
        $files = @scandir($directory);
        if(!is_array($files)) {
            return;
        }
        foreach($files as $file){
            if($file === "." || $file === "..") {
                continue;
            }
            if(is_dir($directory . $file)){
                self::getLastModificationTime($directory.$file."/", $time);
                continue;
            }
            $fileTime = filemtime($directory.$file);
            if($fileTime > $time) {
                $time = (int)$fileTime;
            }
        }
    }
}