<?php

declare(strict_types=1);

namespace manager\task;

use manager\thread\ThreadProgressUpdateTrait;
use function igbinary_serialize;
use function is_scalar;

abstract class AsyncTask extends \ThreadedRunnable{
    use ThreadProgressUpdateTrait;

    /** @var AsyncWorker|null */
    public $worker;

    protected bool $running = false;
    protected bool $finished = false;

    protected mixed $result = null;
    protected bool $serialized = false;

    public function getResult(): mixed{
        if($this->serialized){
            return igbinary_unserialize($this->result);
        }
        return $this->result;
    }

    public function setResult(mixed $result): void{
        if($this->serialized = !is_scalar($result)) {
            $result = igbinary_serialize($result);
        }
        $this->result = $result;
    }

    public function run(): void{
        $this->running = true;
        $this->onRun();
        $this->finished = true;
        $this->running = false;

        gc_enable();
        gc_collect_cycles();
        gc_mem_caches();
    }

    public function isRunning(): bool{
        return $this->running;
    }

    public function isFinished(): bool{
        return $this->finished;
    }

    public function stop(): void {
        $this->running = false;
    }

    abstract public function onRun(): void;

    public function onCompletion(): void {}
}