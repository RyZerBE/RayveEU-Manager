<?php

declare(strict_types=1);

namespace manager\task;

use Closure;
use manager\Manager;

class TaskManager {
    protected static TaskManager $instance;

    /** @var Task[][]  */
    protected array $tasks = [];

    public function __construct(){
        self::$instance = $this;
    }

    public static function getInstance(): TaskManager{
        return self::$instance;
    }

    public function submitTask(Task $task, ?int $delay = null): void {
        $delay = $delay ?? $task->getDelay();
        $this->tasks[Manager::getInstance()->getTick() + $delay][] = $task;
    }

    public function submitClosure(int $delay, Closure $closure): void {
        $this->submitTask(
            new class($delay, $closure) extends Task {
                public function __construct(
                    int $delay,
                    protected Closure $closure
                ){
                    parent::__construct($delay);
                }

                public function onRun(): void{
                    ($this->closure)();
                }
            }
        );
    }

    public function tick(): void {
        $tick = Manager::getInstance()->getTick();
        foreach($this->tasks[$tick] ?? [] as $key => $task) {
            $task->onRun();
            if($task->isCancelled() || !$task->isRepeat()) {
                continue;
            }
            $this->submitTask($task, $task->getPeriod());
        }
        unset($this->tasks[$tick]);
    }
}