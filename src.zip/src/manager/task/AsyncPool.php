<?php

declare(strict_types=1);

namespace manager\task;

use Closure;
use manager\thread\Worker;
use Pool;
use ThreadedArray;
use function array_key_first;
use function asort;

class AsyncPool extends Pool {
    public const SIZE = 12;

    public static AsyncPool $instance;

    /** @var Worker[] */
    protected array $workersPool = [];
    /** @var AsyncTask[] */
    protected array $asyncTasksPool = [];

    public function __construct(){
        self::$instance = $this;
        parent::__construct(self::SIZE, AsyncWorker::class);
    }

    public static function getInstance(): AsyncPool{
        return self::$instance;
    }

    public function submitClosure(Closure $closure, ?Closure $onCompletion = null): void{
        $this->submitAsyncTask(new class($closure, $onCompletion) extends AsyncTask {
                public function __construct(
                    protected Closure $closure,
                    protected ?Closure $onCompletion = null
                ){}

                public function onRun(): void{
                    $this->setResult(($this->closure)());
                }

                public function onCompletion(): void{
                    if($this->onCompletion !== null){
                        ($this->onCompletion)($this->getResult());
                    }
                }
            });
    }

    public function submitAsyncTask(AsyncTask $task, ?int $worker = null): void{
        $workers = [];
        if($worker === null) {
            for($id = 0; $id <= self::SIZE; $id++){
                $workers[$id] = $this->getWorker($id)->getStacked();
                if(isset($this->asyncTasksPool[$id])) {
                    $workers[$id]++;
                }
            }
        }
        asort($workers);
        $worker ??= array_key_first($workers);
        $task->progressUpdates = new ThreadedArray();
        $this->asyncTasksPool[$worker] = $task;
        $this->getWorker($worker)->stack($task);
    }

    public function getWorker(int $id): Worker{
        if(!isset($this->workersPool[$id])){
            $this->workersPool[$id] = new AsyncWorker($id);
            $this->workersPool[$id]->start();
        }
        return $this->workersPool[$id];
    }

    /**
     * @return Worker[]
     */
    public function getWorkers(): array{
        return $this->workersPool;
    }

    public function tick(): void{
        foreach($this->asyncTasksPool as $id => $task){
            $task->checkProgressUpdates();
            if(!$task->isFinished()){
                continue;
            }
            $task->onCompletion();
            unset($this->asyncTasksPool[$id]);
        }
    }
}