<?php

declare(strict_types=1);

namespace manager\task;

use manager\thread\Worker;

class AsyncWorker extends Worker {
    public function __construct(
        protected int $id
    ){}

    public function getId(): int{
        return $this->id;
    }

    public function run(): void{
        enableAutoLoader();
        gc_enable();
        gc_collect_cycles();
        gc_mem_caches();
    }
}