<?php

declare(strict_types=1);

namespace manager\task;

use manager\Manager;

abstract class Task {
    protected bool $cancelled = false;

    public function __construct(
        protected int $delay,
        protected bool $repeat = false,
        protected int $period = Manager::TICKS_PER_SECOND
    ){}

    public function getDelay(): int{
        return $this->delay;
    }

    public function isRepeat(): bool{
        return $this->repeat;
    }

    public function getPeriod(): int{
        return $this->period;
    }

    public function cancel(): void {
        $this->cancelled = true;
    }

    public function isCancelled(): bool{
        return $this->cancelled;
    }

    public function onRun(): void {}
}