<?php

declare(strict_types=1);

namespace manager\player\object;

use lookup\object\Friend;
use manager\Manager;
use manager\player\PlayerSession;
use manager\player\PlayerSessionManager;
use manager\task\AsyncPool;
use manager\task\TaskManager;
use provider\PlayerFriendsProvider;

class FriendManager{

    /** @var Friend[]  */
    protected array $friends = [];
    /** @var string[]  */
    protected array $friendRequests = [];

    public function __construct(
        private PlayerSession $session
    ){}

    /**
     * @return Friend[]
     */
    public function getFriends(): array{
        return array_map(function(string $friend): Friend {
            return $this->getFriend($friend);
        }, array_keys($this->friends));
    }

    public function addFriend(Friend $friend, bool $store = false): void {
        $this->friends[$friend->getXboxId()] = $friend;

        if($store) {
            $player = $this->session->getXboxId();
            $friend = $friend->getXboxId();
            AsyncPool::getInstance()->submitClosure(function() use ($player, $friend): void {
                $mysqli = Manager::createMySQLConnection();
                PlayerFriendsProvider::addFriend($mysqli, $player, $friend);
                mysqli_close($mysqli);
            });
        }
    }

    public function removeFriend(Friend $friend, bool $store = false): void {
        unset($this->friends[$friend->getXboxId()]);

        if($store) {
            $player = $this->session->getXboxId();
            $friend = $friend->getXboxId();
            AsyncPool::getInstance()->submitClosure(function() use ($player, $friend): void {
                $mysqli = Manager::createMySQLConnection();
                PlayerFriendsProvider::removeFriend($mysqli, $player, $friend);
                mysqli_close($mysqli);
            });
        }
    }

    public function getFriend(string $xboxId): ?Friend {
        $friend = $this->friends[$xboxId] ?? null;
        if($friend === null) {
            return null;
        }
        $friend->setOnline(PlayerSessionManager::getSessionByXboxId($friend->getXboxId()) !== null);
        return $friend;
    }

    public function hasFriendRequest(string $xboxId): bool {
        return in_array($xboxId, $this->getFriendRequests(), true);
    }

    public function getFriendRequests(): array{
        return ($this->friendRequests = array_filter($this->friendRequests, function(string $xboxId): bool {
            return PlayerSessionManager::getSessionByXboxId($xboxId) !== null;
        }));
    }

    public function addFriendRequest(string $xboxId): void {
        $this->friendRequests[] = $xboxId;

        TaskManager::getInstance()->submitClosure(Manager::TICKS_PER_SECOND * 120, function() use ($xboxId): void {
            $this->removeFriendRequest($xboxId);
            $session = PlayerSessionManager::getSessionByXboxId($xboxId);
            if($session === null) {
                return;
            }
            $this->session->sendTranslatedMessage("message.friend_request_expired", [
                "player" => $session->getDisplayName()
            ]);
        });
    }

    public function removeFriendRequest(string $xboxId): void {
        unset($this->friendRequests[array_search($xboxId, $this->friendRequests, true)]);
    }
}