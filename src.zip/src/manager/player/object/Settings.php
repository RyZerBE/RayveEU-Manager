<?php

declare(strict_types=1);

namespace manager\player\object;

use provider\PlayerSettingsProvider;
use RuntimeException;

class Settings {
    private array $values = [];

    public function getAll(): array {
        return $this->values;
    }

    public function getValue(string $key): mixed {
        if(!isset(PlayerSettingsProvider::SETTINGS[$key])) {
            throw new RuntimeException("Undefined setting key '".$key."'.");
        }
        return $this->values[$key] ?? null;
    }

    public function setValues(array $values): void{
        $this->values = $values;
    }

    public function setValue(string $key, mixed $value): void {
        $this->values[$key] = $value;
    }

    public function getString(string $key): string {
        return (string)($this->getValue($key) ?? PlayerSettingsProvider::SETTINGS[$key]);
    }

    public function getInt(string $key): int {
        return (int)($this->getValue($key) ?? PlayerSettingsProvider::SETTINGS[$key]);
    }

    public function getBool(string $key): bool {
        return (bool)($this->getValue($key) ?? PlayerSettingsProvider::SETTINGS[$key]);
    }

    public function getArray(string $key): array {
        return (array)($this->getValue($key) ?? PlayerSettingsProvider::SETTINGS[$key]);
    }
}