<?php

declare(strict_types=1);

namespace manager\player;

use lookup\Setting;
use manager\util\Logger;

class PlayerSessionManager {
    /** @var PlayerSession[]  */
    protected static array $sessions = [];

    public static function getSessions(): array{
        return self::$sessions;
    }

    public static function addSession(PlayerSession $player): PlayerSession {
        return self::$sessions[$player->getXboxId()] = $player;
    }

    public static function removeSession(PlayerSession $player): void {
        unset(self::$sessions[$player->getXboxId()]);
        $player->store(function() use ($player): void {
            Logger::info($player->getName()." left the network.");

            foreach($player->getFriendManager()->getFriends() as $friend) {
                $friendSession = PlayerSessionManager::getSessionByXboxId($friend->getXboxId());
                if($friendSession === null) {
                    continue;
                }
                $joinMessage = $friendSession->getSettings()->getInt(Setting::SHOW_FRIEND_JOIN_MESSAGE);
                if($joinMessage === 2 || (!$friend->isClose() && $joinMessage === 1)) {
                    continue;
                }
                $friendSession->sendTranslatedMessage("message.friend_offline", [
                    "player" => $player->getName()
                ]);
            }
        });
    }

    public static function getSessionByXboxId(string $xboxId): ?PlayerSession {
        return self::$sessions[$xboxId] ?? null;
    }

    public static function getSessionByName(string $name): ?PlayerSession {
        foreach(self::getSessions() as $session) {
            if($session->getName() === $name) {
                return $session;
            }
        }
        return null;
    }
}