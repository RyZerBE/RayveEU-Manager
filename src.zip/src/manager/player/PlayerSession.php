<?php

declare(strict_types=1);

namespace manager\player;

use Closure;
use language\Language;
use lookup\object\Friend;
use lookup\ServerSetting;
use lookup\Setting;
use manager\Manager;
use manager\network\packet\Packet;
use manager\network\packet\PlayerKickPacket;
use manager\network\packet\PlayerMessagePacket;
use manager\network\packet\PlayerTransferNotifyPacket;
use manager\party\PartyManager;
use manager\player\object\FriendManager;
use manager\player\object\Settings;
use manager\server\ServerManager;
use manager\task\AsyncPool;
use manager\task\TaskManager;
use manager\util\Logger;
use manager\util\Proxy;
use party\Party;
use provider\PlayerAddressesProvider;
use provider\PlayerCloseFriendsProvider;
use provider\PlayerDataProvider;
use provider\PlayerDevicesProvider;
use provider\PlayerFriendsProvider;
use provider\PlayerPunishmentsProvider;
use provider\PlayerSettingsProvider;
use provider\tool\PlayerAccountsProvider;
use restapi\endpoint\PlayerEndpoint;
use restapi\endpoint\PlayersEndpoint;
use restapi\RestAPI;

class PlayerSession {
    protected int $joinTime;
    protected int $onlineTime;

    protected bool $initialized = false;

    protected ?int $party = null;
    protected array $partyInvites = [];

    public ?string $nick = null;

    protected Settings $settings;
    protected FriendManager $friendManager;

    public bool $transfer = false;
    private int $transferFails = 0;

    private string $server = "???";

    public function __construct(
        protected string $xboxId,
        protected string $name,
        protected string $playFabId,
        protected string $clientRandomId
    ){
        $this->settings = new Settings();

        $this->friendManager = new FriendManager($this);
    }

    public function getXboxId(): string{
        return $this->xboxId;
    }

    public function getName(): string{
        return $this->name;
    }

    public function getDisplayName(): string {
        return $this->getNick() ?? $this->getName();
    }

    public function getLanguage(): string{
        return $this->settings->getString(Setting::LANGUAGE);
    }

    public function getSettings(): Settings{
        return $this->settings;
    }

    public function getFriendManager(): FriendManager{
        return $this->friendManager;
    }

    public function getNick(): ?string{
        return $this->nick;
    }

    public function setNick(?string $nick): void{
        $this->nick = $nick;
    }

    public function isInitialized(): bool{
        return $this->initialized;
    }

    public function setInitialized(bool $initialized): void{
        $this->initialized = $initialized;
    }

    public function refreshSettings(Closure $closure): void {
        $xboxId = $this->getXboxId();
        AsyncPool::getInstance()->submitClosure(function() use ($xboxId): array {
            $mysqli = Manager::createMySQLConnection();
            $settings = PlayerSettingsProvider::get($mysqli, $xboxId);
            mysqli_close($mysqli);
            return $settings;
        }, function(array $settings) use ($closure): void {
            $this->settings->setValues($settings);
            ($closure)();
        });
    }

    public function initialize(Closure $closure): void {
        if($this->isInitialized()){
            ($closure)();
            return;
        }
        $xboxId = $this->getXboxId();
        $username = $this->getName();
        $playFabId = $this->playFabId;
        $clientRandomId = $this->clientRandomId;
        AsyncPool::getInstance()->submitClosure(function() use ($xboxId, $username, $playFabId, $clientRandomId): bool|array {
            $mysqli = Manager::createMySQLConnection();

            if(!PlayerDataProvider::exists($mysqli, $xboxId)) {
                PlayerDataProvider::register($mysqli, $xboxId, $username, $playFabId, $clientRandomId);
                PlayerSettingsProvider::register($mysqli, $xboxId);
            } else {
                PlayerDataProvider::update($mysqli, $xboxId, [
                    "username" => $username
                ]);
            }

            /*
            $devices = PlayerDevicesProvider::get($mysqli, $xboxId);
            if(!in_array($restPlayer->deviceId, $devices, true)) {
                PlayerDevicesProvider::add($mysqli, $xboxId, $restPlayer->deviceId);
            }
            */

            /*
            $addresses = PlayerAddressesProvider::get($mysqli, $xboxId);
            if(!in_array($restPlayer->address, $addresses, true)) {
                PlayerAddressesProvider::add($mysqli, $xboxId, $restPlayer->address);
            }
            */

            $playerData = PlayerDataProvider::get($mysqli, $xboxId);
            $playerSettings = PlayerSettingsProvider::get($mysqli, $xboxId);

            $secondAccounts = [];
            if(!$playerData->accountDetectionBypass) {
                $secondAccounts = PlayerAccountsProvider::get($mysqli, $xboxId, $playFabId, $clientRandomId, true);
            }

            $punishments = PlayerPunishmentsProvider::get($mysqli, $xboxId);
            foreach($secondAccounts as $account => $chance) {
                $punishments += PlayerPunishmentsProvider::get($mysqli, (string)$account);
            }

            if(!empty($punishments)) {
                Logger::debug($username." tried to join the network.");
                return false;
            }

            $friends = PlayerFriendsProvider::getFriends($mysqli, $xboxId);
            $closeFriends = PlayerCloseFriendsProvider::getCloseFriends($mysqli, $xboxId);

            mysqli_close($mysqli);
            return [
                $playerData,
                $playerSettings,
                $friends,
                $closeFriends,
            ];
        }, function(bool|array $data) use ($closure): void {
            if(is_bool($data)) {
                $this->sendPacket(PlayerKickPacket::make($this, $this->translate("§cYou are banned from the network!")));
                return;
            }
            $this->settings->setValues($data[1]);

            $this->onlineTime = $data[0]->onlineTime;
            $this->joinTime = time();

            foreach($data[2] as $friend) {
                $this->friendManager->addFriend($friend);
            }
            foreach($data[3] as $friend) {
                $this->friendManager->getFriend($friend)?->setClose(true);
            }

            ($closure)();
            $this->setInitialized(true);
        });
    }

    public function store(Closure $closure): void {
        if(!$this->isInitialized()) {
            return;
        }
        $xboxId = $this->getXboxId();
        $onlineTime = $this->onlineTime + (time() - $this->joinTime);
        $closeFriends = array_map(function(Friend $friend): string {
            return $friend->getXboxId();
        }, array_filter($this->friendManager->getFriends(), function(Friend $friend): bool {
            return $friend->isClose();
        }));
        AsyncPool::getInstance()->submitClosure(function() use ($xboxId, $onlineTime, $closeFriends): void {
            $mysqli = Manager::createMySQLConnection();
            PlayerDataProvider::update($mysqli, $xboxId, [
                "online_time" => $onlineTime
            ]);
            PlayerCloseFriendsProvider::setCloseFriends($mysqli, $xboxId, $closeFriends);

        }, function() use ($closure): void {
            ($closure)();
            $this->setInitialized(false);
        });

        $party = $this->getParty();
        if($party !== null) {
            PartyManager::removeMember($party, $this);
        }
    }

    public function checkOnlineState(): void {
        $xboxId = $this->getXboxId();
        AsyncPool::getInstance()->submitClosure(function() use ($xboxId): bool {
            return RestAPI::execute(["title" => "§r"], "player/".$xboxId."/title")["success"] ?? false;
        }, function(bool $online) use ($xboxId): void {
            if($online) {
                return;
            }
            $session = PlayerSessionManager::getSessionByXboxId($xboxId);
            if($session === null) {
                return;
            }
            PlayerSessionManager::removeSession($session);
        });
    }

    public function sendMessage(string $message): void {
        $xboxId = $this->getXboxId();
        AsyncPool::getInstance()->submitClosure(function() use ($message, $xboxId): void {
            PlayerEndpoint::message($xboxId, $message);
        });
    }

    public function sendTranslatedMessage(string $key, array $parameter = [], ?string $prefix = null): void {
        $this->sendMessage($this->translate($key, $parameter, $prefix));
    }

    public function translate(string $key, array $parameter = [], ?string $prefix = null): string {
        return Language::translate($key, $parameter, $this->getLanguage(), $prefix);
    }

    public function getSessionDuration(): int {
        return time() - $this->joinTime;
    }

    public function getParty(): ?Party{
        return PartyManager::getPartyById($this->party ?? -1);
    }

    public function setParty(Party|int|null $party): void{
        $this->party = ($party instanceof Party ? $party->getId() : $party);
        if($this->getParty() !== null) {
            $this->clearPartyInvites();
        }
    }

    public function inviteToParty(Party $party): void {
        $this->partyInvites[$party->getId()] = $party->getId();
    }

    public function hasPartyInvite(Party $party): bool {
        return isset($this->partyInvites[$party->getId()]);
    }

    public function removePartyInvite(Party|int $party): void {
        unset($this->partyInvites[($party instanceof Party ? $party->getId() : $party)]);
    }

    public function clearPartyInvites(): void {
        $this->partyInvites = [];
    }

    /**
     * @return Party[]
     */
    public function getPartyInvites(): array {
        return array_filter(array_map(function(int $party): ?Party {
            return PartyManager::getPartyById($party);
        }, $this->partyInvites), function(?Party $party): bool {
            return $party !== null;
        });
    }

    public function transfer(string $serverName): void {
        if($this->transfer) {
            $this->sendTranslatedMessage("message.already_in_transfer_queue");
            if(++$this->transferFails >= 1) {
                $this->transfer = false;
            }
            return;
        }
        $this->transferFails = 0;
        $server = ServerManager::getInstance()->getServerByName($serverName);
        if($server === null) {
            $this->sendTranslatedMessage("message.transfer_failed_reason_server_offline");
            return;
        }
        $xboxId = $this->getXboxId();
        if(!$server->isBlocked()) {
            $settings = $server->getSettings();
            $maxPlayers = $settings[ServerSetting::MAX_PLAYERS] ?? $settings[ServerSetting::PLAYERS_PER_TEAM] ?? 999999;

            $party = $this->getParty();
            if($party !== null && $party->getOwner()?->getXboxId() === $xboxId) {
                if(count($party->getMembers()) > $maxPlayers) {
                    $this->sendTranslatedMessage("message.party_too_big");
                    return;
                }
                TaskManager::getInstance()->submitClosure(20, function() use ($party, $xboxId, $serverName): void {
                    foreach($party->getMembers() as $member) {
                        if($member->getXboxId() === $xboxId) {
                            continue;
                        }
                        PlayerSessionManager::getSessionByXboxId($member->getXboxId())?->transfer($serverName);
                    }
                });
            }
        }
        $this->transfer = true;
        $this->sendTranslatedMessage("message.server_transfer");
        AsyncPool::getInstance()->submitClosure(function() use ($serverName, $xboxId): void {
            PlayerEndpoint::transfer($xboxId, $serverName);
        }, function(): void {
            $this->transfer = false;
        });
    }

    public function sendPacket(Packet $packet): void {
        ServerManager::getInstance()->getServerByName($this->server)?->sendPacket($packet);
    }

    public function setServer(string $server): void{
        $this->server = $server;
    }

    public function getServer(): string{
        return $this->server;
    }
}