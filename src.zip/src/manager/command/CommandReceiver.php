<?php

declare(strict_types=1);

namespace manager\command;

use manager\thread\Thread;
use function str_starts_with;
use function substr;

class CommandReceiver extends Thread {
    public const TICKS_PER_SECOND = 20;

    public function onRun(): void{
        $nextGarbageCollection = 100;
        while($this->isRunning()) {
            if(--$nextGarbageCollection <= 0) {
                gc_enable();
                gc_collect_cycles();
                gc_mem_caches();

                $nextGarbageCollection = 100;
            }
            usleep((int)(1000000 / self::TICKS_PER_SECOND));
            $fh = @fopen("php://stdin", "r");
            if($fh === false) {
                break;
            }
            stream_set_blocking($fh, false);
            $get = fgets($fh);
            if($get === false){
                continue;
            }
            $userInput = trim($get);
            fclose($fh);
            if(empty($userInput)){
                continue;
            }
            if(str_starts_with($userInput, "/")) {
                $userInput = substr($userInput, 1);
            }
            $this->publishProgress($userInput);
        }
    }

    public function onProgressReceive(mixed $progress): void{
        CommandManager::dispatchCommand($progress);
    }
}