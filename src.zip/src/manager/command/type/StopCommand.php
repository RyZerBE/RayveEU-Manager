<?php

declare(strict_types=1);

namespace manager\command\type;

use manager\command\Command;
use manager\Manager;

class StopCommand extends Command {
    public function __construct(){
        parent::__construct("stop");
    }

    public function execute(array $args): void{
        Manager::getInstance()->shutdown();
    }
}