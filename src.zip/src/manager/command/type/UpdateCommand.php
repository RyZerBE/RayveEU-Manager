<?php

declare(strict_types=1);

namespace manager\command\type;

use manager\command\Command;
use manager\Manager;
use manager\server\group\GroupManager;
use manager\server\ServerManager;
use manager\util\Logger;

class UpdateCommand extends Command{
    public function __construct(){
        parent::__construct("update", ["u"]);
    }

    public function execute(array $args): void{
        $groups = GroupManager::getInstance()->getGroups();
        if(isset($args[0])) {
            $group = GroupManager::getInstance()->getGroup($args[0]);
            if($group !== null) {
                $groups = [$group];
            }
        }

        Manager::getInstance()->getPluginUpdater()->updateGroupPlugins();

        $path = Manager::getBasePath()."../";
        foreach($groups as $group) {
            Logger::command("Updating ".$group->getFileName()."...");
            @exec($path."Source/bin_manager/php7/bin/php ".$path."Source/update_plugins.php ".Manager::getBasePath()."template_plugins/".$group->getFileName()."/");
            foreach(ServerManager::getInstance()->getServersByGroup($group) as $server){
                $server->flagForShutdown();
            }
            $group->serverCooldown = 0;
        }
        Logger::command("Done!");
    }
}