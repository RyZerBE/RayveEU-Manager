<?php

declare(strict_types=1);

namespace manager\command\type;

use manager\command\Command;
use manager\command\SubCommand;
use manager\server\ServerManager;
use manager\util\Logger;

class ServerCommand extends Command {
    public function __construct(){
        parent::__construct("server");

        $this->registerSubCommands(
            new SubCommand("stopall", function(): void {
                ServerManager::getInstance()->shutdown();
                Logger::command("Stopped all servers.");
            }),
            new SubCommand("list", function(): void {
                Logger::command("List of all servers:");
                foreach(ServerManager::getInstance()->getServers() as $server) {
                    $status = $server->getStatus();
                    Logger::command($server->getName()." » ".$status->onlinePlayers."/".$status->maxOnlinePlayers." | ".$status->tpsAverage."(".$status->tickUsageAverage."%) | ".$status->packetDelay."s");
                }
            }),
        );
    }
}