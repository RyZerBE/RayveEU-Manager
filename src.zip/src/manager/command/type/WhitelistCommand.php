<?php

declare(strict_types=1);

namespace manager\command\type;

use manager\command\Command;
use manager\command\SubCommand;
use manager\Manager;
use manager\util\Logger;
use manager\util\Whitelist;

class WhitelistCommand extends Command{
    public function __construct(){
        parent::__construct("whitelist");
        $this->registerSubCommands(
            new SubCommand("reload", function(): void {
                if(!is_file(Manager::getBasePath()."whitelist.yml")) {
                    Manager::getInstance()->getWhitelist()->save();
                }
                Manager::getInstance()->setWhitelist(new Whitelist());
                Logger::command("Successfully reloaded whitelist.");
            })
        );
    }
}