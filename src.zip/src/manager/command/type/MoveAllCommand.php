<?php

declare(strict_types=1);

namespace manager\command\type;

use manager\command\Command;
use manager\player\PlayerSessionManager;
use manager\server\ServerManager;
use manager\util\Logger;

class MoveAllCommand extends Command{
    public function __construct(){
        parent::__construct("moveall");
    }

    public function execute(array $args): void{
        $server = ServerManager::getInstance()->getServerByName($args[0] ?? "");
        if($server === null) {
            Logger::command("Unknown server.");
            return;
        }
        foreach(PlayerSessionManager::getSessions() as $session) {
            $session->transfer($server->getName());
        }
        Logger::command("Moved all players");
    }
}