<?php

declare(strict_types=1);

namespace manager\command\type;

use manager\command\Command;
use manager\util\Logger;

class MemoryCommand extends Command{
    public function __construct(){
        parent::__construct("memory");
    }

    public function execute(array $args): void{
        Logger::command("Usage (Peak): ".(memory_get_peak_usage(true) * 0.001)."mb");
        Logger::command("Usage: ".(memory_get_usage(true) * 0.001)."mb");
    }
}