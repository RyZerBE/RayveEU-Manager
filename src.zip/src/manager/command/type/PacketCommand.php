<?php

declare(strict_types=1);

namespace manager\command\type;

use manager\command\Command;
use manager\command\SubCommand;
use manager\util\Logger;
use packet\PacketManager;
use ReflectionClass;

class PacketCommand extends Command{
    public function __construct(){
        parent::__construct("packet", ["pk"]);
        $this->registerSubCommands(
            new SubCommand("logger", function(): void {
                Logger::$showPacketContent = !Logger::$showPacketContent;
                if(Logger::$showPacketContent) {
                    Logger::command("Packet content will be logged.");
                } else {
                    Logger::command("Packet content will not be logged.");
                }
            }),
            new SubCommand("list", function(): void {
                $packets = [];
                foreach(PacketManager::getInstance()->getPackets() as $packet) {
                    $reflection = new ReflectionClass($packet);
                    $packets[] = $reflection->getShortName().": ".$packet->getIdentifier();
                }
                Logger::command("List of all registered packets:\n".implode("\n- ", $packets));
            })
        );
    }
}