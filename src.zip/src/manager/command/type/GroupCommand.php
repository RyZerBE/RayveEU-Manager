<?php

declare(strict_types=1);

namespace manager\command\type;

use manager\command\Command;
use manager\command\SubCommand;
use manager\server\group\GroupManager;
use manager\server\ServerManager;
use manager\util\Logger;

class GroupCommand extends Command {
    public function __construct(){
        parent::__construct("group");

        $this->registerSubCommands(
            new SubCommand("minserver", function(array $args): bool {
                $group = GroupManager::getInstance()->getGroup($args[1] ?? "");
                $amount = is_numeric($args[2] ?? null) ? $args[2] : null;
                if($group === null || $amount === null) {
                    return false;
                }
                $group->setMinServer((int)$amount);
                Logger::command("Set server minimum of group ".$group->getFileName()." to ".$amount.".");
                return true;
            }, [
                "group" => SubCommand::TYPE_STRING,
                "amount" => SubCommand::TYPE_INT,
            ]),
            new SubCommand("list", function(): void {
                Logger::command("List of all groups:");
                foreach(GroupManager::getInstance()->getGroups() as $group) {
                    Logger::command("   » ".$group->getFileName());
                    Logger::command("     Default: ".($group->isDefault() ? "Yes" : "No"));
                    Logger::command("     Server Minimum: ".$group->getMinServer());
                    Logger::command("     Server Amount: ".count(ServerManager::getInstance()->getServersByGroup($group)));
                }
            })
        );
    }
}