<?php

declare(strict_types=1);

namespace manager\command\type;

use manager\command\Command;
use manager\command\SubCommand;
use manager\player\PlayerSessionManager;
use manager\util\Logger;

class PlayerCommand extends Command {
    public function __construct(){
        parent::__construct("player");
        $this->registerSubCommands(
            new SubCommand("list", function(): void {
                Logger::command("List of all online players:");
                Logger::command("Total: ".count(PlayerSessionManager::getSessions()));
                foreach(PlayerSessionManager::getSessions() as $session) {
                    Logger::command($session->getName());
                }
            })
        );
    }
}