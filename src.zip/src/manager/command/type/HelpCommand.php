<?php

declare(strict_types=1);

namespace manager\command\type;

use manager\command\Command;
use manager\command\CommandManager;
use manager\util\Logger;

class HelpCommand extends Command {
    public function __construct(){
        parent::__construct("help");
    }

    public function execute(array $args): void{
        Logger::command("List of all commands:");
        foreach(CommandManager::getCommands() as $command) {
            Logger::command("/".$command->getName());
            foreach($command->getSubCommands() as $subCommand) {
                Logger::command("   » ".$subCommand->getUsage());
            }
        }
    }
}