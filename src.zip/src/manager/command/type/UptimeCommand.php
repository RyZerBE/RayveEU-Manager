<?php

declare(strict_types=1);

namespace manager\command\type;

use manager\command\Command;
use manager\util\Logger;
use manager\util\Utils;

class UptimeCommand extends Command {
    public function __construct(){
        parent::__construct("uptime");
    }

    public function execute(array $args): void{
        Logger::command("Manager Uptime:");
        Logger::command(Utils::getUptime());
    }
}