<?php

declare(strict_types=1);

namespace manager\command;

use Closure;

class SubCommand {
    public const TYPE_STRING = "string";
    public const TYPE_INT = "int";
    public const TYPE_FLOAT = "float";
    public const TYPE_BOOl = "bool";
    public const TYPE_MIXED = "mixed";

    public Command $command;

    public function __construct(
        protected string $name,
        protected ?Closure $closure = null,
        protected array $arguments = [],
        protected array $aliases = [],
    ){}

    public function getName(): string{
        return $this->name;
    }

    public function getAliases(): array{
        return $this->aliases;
    }

    public function getCommand(): Command{
        return $this->command;
    }

    public function getUsage(): string{
        $usage = $this->getName();
        foreach($this->arguments as $key => $type) {
            $usage .= " [".$type.": ".$key."]";
        }
        return $usage;
    }

    public function sendUsage(): string {
        return "/".$this->command->getName().$this->getUsage();
    }

    public function tryExecute(array $args): void {
        if($this->closure !== null) {
            $result = ($this->closure)($args);
            if($result === false) {
                $this->sendUsage();
            }
            return;
        }
        $this->execute($args);
    }

    public function execute(array $args): void {}
}