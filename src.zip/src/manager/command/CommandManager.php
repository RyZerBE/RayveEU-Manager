<?php

declare(strict_types=1);

namespace manager\command;

use manager\util\Logger;
use function array_shift;
use function explode;
use function reset;

class CommandManager {
    /** @var Command[]  */
    protected static array $commands = [];

    public static function getCommands(): array{
        return self::$commands;
    }

    public static function register(Command $command): void {
        self::$commands[$command->getName()] = $command;
        foreach($command->getAliases() as $alias) {
            self::$commands[$alias] = $command;
        }
    }

    public static function dispatchCommand(string $command): void {
        $arguments = explode(" ", $command);
        $name = array_shift($arguments);
        if(!isset(self::$commands[$name])) {
            Logger::command("Unknown command.");
            return;
        }
        reset($arguments);
        self::$commands[$name]->tryExecute($arguments);
    }
}