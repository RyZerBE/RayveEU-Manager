<?php

declare(strict_types=1);

namespace manager\command;

use manager\util\Logger;
use function reset;

abstract class Command {
    /** @var SubCommand[]  */
    protected array $subCommands = [];

    public function __construct(
        protected string $name,
        protected array $aliases = []
    ){}

    public function getName(): string{
        return $this->name;
    }

    public function getAliases(): array{
        return $this->aliases;
    }

    public function sendUsage(): void {
        $subCommands = $this->getSubCommands();
        Logger::command(ucfirst($this->getName())." Command Help:");
        if(empty($subCommands)) {
            Logger::command("/".$this->getName());
            return;
        }
        foreach($subCommands as $subCommand) {
            Logger::command("/".$this->getName()." ".$subCommand->getUsage());
        }
    }

    public function getSubCommands(): array{
        return $this->subCommands;
    }

    public function registerSubCommand(SubCommand $subCommand): void {
        $subCommand->command = $this;
        $this->subCommands[$subCommand->getName()] = $subCommand;
        foreach($subCommand->getAliases() as $alias) {
            $this->subCommands[$alias] = $subCommand;
        }
    }

    public function registerSubCommands(SubCommand... $subCommands): void {
        foreach($subCommands as $subCommand) {
            $this->registerSubCommand($subCommand);
        }
    }

    public function tryExecute(array $args): void {
        $subCommand = $this->subCommands[$args[0] ?? -1] ?? null;
        if($subCommand !== null) {
            unset($args[0]);
            reset($args);
            $subCommand->tryExecute($args);
            return;
        }
        $this->execute($args);
    }

    public function execute(array $args): void {
        $this->sendUsage();
    }
}