<?php

declare(strict_types=1);

namespace manager\registry;

use manager\network\packet\AcceptLoginPacket;
use manager\network\packet\CreateGameServerPingPacket;
use manager\network\packet\CreateServerPongPacket;
use manager\network\packet\CreateReplayServerPacket;
use manager\network\packet\EmptyPingPacket;
use manager\network\packet\EmptyPongPacket;
use manager\network\packet\FinishLoginPacket;
use manager\network\packet\FriendListPingPacket;
use manager\network\packet\FriendListPongPacket;
use manager\network\packet\FriendRemovePacket;
use manager\network\packet\FriendRequestAcceptPacket;
use manager\network\packet\FriendRequestListPingPacket;
use manager\network\packet\FriendRequestListPongPacket;
use manager\network\packet\FriendRequestSendPacket;
use manager\network\packet\FriendSetClosePacket;
use manager\network\packet\GameServerSettingsPacket;
use manager\network\packet\GroupInfoPingPacket;
use manager\network\packet\GroupInfoPongPacket;
use manager\network\packet\GroupListPingPacket;
use manager\network\packet\GroupListPongPacket;
use manager\network\packet\LoginPingPacket;
use manager\network\packet\PartyAccessStatusPacket;
use manager\network\packet\PartyCreatePacket;
use manager\network\packet\PartyDeletePacket;
use manager\network\packet\PartyInfoPacket;
use manager\network\packet\PartyInfoPingPacket;
use manager\network\packet\PartyInviteAcceptPacket;
use manager\network\packet\PartyInviteDeclinePacket;
use manager\network\packet\PartyInvitePacket;
use manager\network\packet\PartyInvitesPacket;
use manager\network\packet\PartyListPingPacket;
use manager\network\packet\PartyListPongPacket;
use manager\network\packet\PartyMemberAddPacket;
use manager\network\packet\PartyMemberRemovePacket;
use manager\network\packet\PartySendServerPacket;
use manager\network\packet\PartySetMemberRolePacket;
use manager\network\packet\PlayerCheckOnlineStatusPacket;
use manager\network\packet\PlayerJoinPacket;
use manager\network\packet\PlayerKickPacket;
use manager\network\packet\PlayerMessagePacket;
use manager\network\packet\PlayerQuitPacket;
use manager\network\packet\PlayerSearchPingPacket;
use manager\network\packet\PlayerSearchPongPacket;
use manager\network\packet\PlayerTransferExecutePacket;
use manager\network\packet\PlayerTransferFailPacket;
use manager\network\packet\PlayerTransferLobbyPacket;
use manager\network\packet\PlayerTransferNotifyPacket;
use manager\network\packet\PlayerTransferPacket;
use manager\network\packet\PlayerVerifyPacket;
use manager\network\packet\RefreshPlayerSettingsPacket;
use manager\network\packet\SendMessagePacket;
use manager\network\packet\SendTranslationMessagePacket;
use manager\network\packet\ServerBlockPacket;
use manager\network\packet\ServerDisconnectPacket;
use manager\network\packet\ServerListPingPacket;
use manager\network\packet\ServerListPongPacket;
use manager\network\packet\ServerRejoinPacket;
use manager\network\packet\ServerShutdownPacket;
use manager\network\packet\ServerStatusPacket;
use manager\network\packet\ServerStopPacket;
use manager\network\packet\ServerSyncRejoinCachePacket;
use packet\BasePacket;
use packet\PacketManager;

class PacketRegistry {
    public function __construct(){
        self::register(new EmptyPingPacket());
        self::register(new EmptyPongPacket());

        self::register(new AcceptLoginPacket());
        self::register(new LoginPingPacket());
        self::register(new FinishLoginPacket());

        self::register(new ServerDisconnectPacket());
        self::register(new ServerShutdownPacket());
        self::register(new ServerStatusPacket());
        self::register(new ServerListPingPacket());
        self::register(new ServerListPongPacket());
        self::register(new ServerStopPacket());
        self::register(new ServerBlockPacket());
        self::register(new ServerSyncRejoinCachePacket());
        self::register(new ServerRejoinPacket());

        self::register(new PlayerJoinPacket());
        self::register(new PlayerQuitPacket());
        self::register(new PlayerCheckOnlineStatusPacket());
        self::register(new PlayerVerifyPacket());
        self::register(new PlayerTransferLobbyPacket());
        self::register(new PlayerTransferPacket());
        self::register(new PlayerTransferNotifyPacket());
        self::register(new PlayerTransferExecutePacket());
        self::register(new PlayerMessagePacket());
        self::register(new PlayerTransferFailPacket());
        self::register(new PlayerKickPacket());
        self::register(new PlayerSearchPingPacket());
        self::register(new PlayerSearchPongPacket());

        self::register(new SendMessagePacket());
        self::register(new SendTranslationMessagePacket());

        self::register(new GroupInfoPongPacket());
        self::register(new GroupInfoPingPacket());
        self::register(new GroupListPingPacket());
        self::register(new GroupListPongPacket());

        self::register(new PartyCreatePacket());
        self::register(new PartyInfoPacket());
        self::register(new PartyInfoPingPacket());
        self::register(new PartySendServerPacket());
        self::register(new PartyListPongPacket());
        self::register(new PartyListPingPacket());
        self::register(new PartyMemberAddPacket());
        self::register(new PartyMemberRemovePacket());
        self::register(new PartyDeletePacket());
        self::register(new PartyAccessStatusPacket());
        self::register(new PartyInvitePacket());
        self::register(new PartyInvitesPacket());
        self::register(new PartyInviteAcceptPacket());
        self::register(new PartyInviteDeclinePacket());
        self::register(new PartySetMemberRolePacket());

        self::register(new RefreshPlayerSettingsPacket());

        self::register(new CreateGameServerPingPacket());
        self::register(new CreateServerPongPacket());
        self::register(new GameServerSettingsPacket());
        self::register(new CreateReplayServerPacket());

        self::register(new FriendListPingPacket());
        self::register(new FriendListPongPacket());
        self::register(new FriendRequestSendPacket());
        self::register(new FriendRequestAcceptPacket());
        self::register(new FriendRequestListPingPacket());
        self::register(new FriendRequestListPongPacket());
        self::register(new FriendRemovePacket());
        self::register(new FriendSetClosePacket());
    }

    public static function register(BasePacket $packet): void {
        PacketManager::getInstance()->registerPacket($packet);
    }
}