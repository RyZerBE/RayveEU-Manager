<?php

declare(strict_types=1);

namespace manager\registry;

use manager\command\Command;
use manager\command\CommandManager;
use manager\command\type\GroupCommand;
use manager\command\type\HelpCommand;
use manager\command\type\MemoryCommand;
use manager\command\type\MoveAllCommand;
use manager\command\type\PacketCommand;
use manager\command\type\PlayerCommand;
use manager\command\type\ServerCommand;
use manager\command\type\StopCommand;
use manager\command\type\UpdateCommand;
use manager\command\type\UptimeCommand;
use manager\command\type\WhitelistCommand;

class CommandRegistry {
    public function __construct(){
        self::register(new HelpCommand());
        self::register(new StopCommand());
        self::register(new ServerCommand());
        self::register(new PlayerCommand());
        self::register(new UptimeCommand());
        self::register(new GroupCommand());
        self::register(new PacketCommand());
        self::register(new UpdateCommand());
        self::register(new WhitelistCommand());
        self::register(new MemoryCommand());
        self::register(new MoveAllCommand());
    }

    public static function register(Command $command): void {
        CommandManager::register($command);
    }
}