<?php

declare(strict_types=1);

namespace manager\registry;

use manager\server\group\Group;
use manager\server\group\GroupManager;
use manager\server\group\type\BuildFFAGroup;
use manager\server\group\type\FFAGroup;
use manager\server\group\type\KnockFFAGroup;
use manager\server\group\type\LobbyGroup;
use manager\server\group\type\PartyCubeGroup;
use manager\server\group\type\KitWarsGroup;
use manager\server\group\type\ReplayGroup;
use manager\server\group\type\SumoGroup;
use manager\server\group\type\UHCMeetupGroup;

class GroupRegistry {
    public function __construct(){
        self::register(new LobbyGroup());
        self::register(new KitWarsGroup());
        self::register(new FFAGroup());
        self::register(new BuildFFAGroup());
        self::register(new SumoGroup());
        self::register(new KnockFFAGroup());
        self::register(new PartyCubeGroup());
        self::register(new KitWarsGroup());
        self::register(new UHCMeetupGroup());
        self::register(new ReplayGroup());
    }

    public static function register(Group $group): void {
        GroupManager::getInstance()->registerGroup($group);
    }
}