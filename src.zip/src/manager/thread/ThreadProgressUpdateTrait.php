<?php

declare(strict_types=1);

namespace manager\thread;

trait ThreadProgressUpdateTrait {
    public \ThreadedArray $progressUpdates;

    public function publishProgress(mixed $progress): void {
        $this->progressUpdates[] = igbinary_serialize($progress);
    }

    public function checkProgressUpdates() : void{
        if(!isset($this->progressUpdates)) {
            return;
        }
        while($this->progressUpdates->count() !== 0){
            $progress = $this->progressUpdates->shift();
            $this->onProgressReceive(igbinary_unserialize($progress));
        }
    }

    public function onProgressReceive(mixed $progress): void {
    }
}