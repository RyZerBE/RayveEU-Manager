<?php

declare(strict_types=1);

namespace manager\thread;

abstract class Worker extends \Worker {

}