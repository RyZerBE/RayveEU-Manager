<?php

declare(strict_types=1);

namespace manager\thread;

abstract class Thread extends \Thread {
    use ThreadProgressUpdateTrait;

    protected bool $running = false;

    public function isRunning(): bool{
        return $this->running;
    }

    public function run(): void{
        $this->running = true;
        enableAutoLoader();
        $this->onRun();
        $this->running = false;

        gc_enable();
        gc_collect_cycles();
        gc_mem_caches();
    }

    public function stop(): void {
        $this->running = false;
    }

    abstract public function onRun(): void;
}