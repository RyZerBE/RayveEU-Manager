<?php

declare(strict_types=1);

namespace manager\thread;

class ThreadManager {
    private static ThreadManager $instance;

    /** @var Thread[]  */
    private array $threads = [];

    public function __construct(){
        self::$instance = $this;
    }

    public static function getInstance(): ThreadManager{
        return self::$instance;
    }

    public function getThreads(): array{
        return $this->threads;
    }

    public function addThread(Thread $thread): void {
        $this->threads[] = $thread;
        $thread->progressUpdates = new \ThreadedArray();
        $thread->start();
    }

    public function tick(): void {
        foreach($this->getThreads() as $thread){
            if(!$thread->isRunning()) {
                continue;
            }
            $thread->checkProgressUpdates();
        }
    }

    public function shutdown(): void {
        foreach($this->getThreads() as $thread) {
            $thread->stop();
            $thread->join();
        }
    }
}