<?php

declare(strict_types=1);

namespace manager\party;

use manager\player\PlayerSession;
use manager\player\PlayerSessionManager;
use party\Party;
use party\PartyMember;
use party\PartyRole;

class PartyManager {
    /** @var Party[] */
    protected static array $parties = [];

    public static function getParties(): array{
        return self::$parties;
    }

    public static function getPartyById(int $party): ?Party {
        return self::$parties[$party] ?? null;
    }

    public static function getPartyByPlayer(string $xboxId): ?Party {
        return PlayerSessionManager::getSessionByXboxId($xboxId)?->getParty();
    }

    public static function createParty(string $xboxId): ?Party {
        $player = PlayerSessionManager::getSessionByXboxId($xboxId);
        if($player === null) {
            return null;
        }
        $id = 0;
        while(isset(self::$parties[$id])) {
            $id++;
        }
        $party = new Party($id);
        self::$parties[$party->getId()] = $party;
        $party->broadcastMessage("message.party_created");
        self::addMember($party, $player, PartyRole::OWNER);
        return $party;
    }

    public static function deleteParty(Party $party): void {
        unset(self::$parties[$party->getId()]);
        $party->broadcastMessage("message.party_deleted");
        foreach($party->getMembers() as $member) {
            PlayerSessionManager::getSessionByXboxId($member->getXboxId())?->setParty(null);
        }
    }

    public static function addMember(Party $party, PlayerSession $player, int $role = PartyRole::MEMBER): void {
        $party->addMember($player->getXboxId(), $player->getName(), $player->getNick(), $player->getLanguage(), $role);
        if($role !== PartyRole::OWNER) {
            $party->broadcastMessage("message.party_member_joined", [
                "player" => $player->getDisplayName()
            ]);
        }
        $player->setParty($party);
    }

    public static function removeMember(Party $party, PlayerSession $player): void {
        $party->removeMember($player->getXboxId());
        $oldOwner = $party->getOwner();
        if($oldOwner === null) {
            self::deleteParty($party);
            return;
        }
        $party->broadcastMessage("message.party_member_left", [
            "player" => $player->getDisplayName()
        ]);
        $player->setParty(null);
        $owner = $party->getOwner();
        if(!$owner instanceof PartyMember || count($party->getMembers()) <= 0) {
            self::deleteParty($party);
            return;
        }
        if($oldOwner->getXboxId() !== $owner->getXboxId()) {
            $party->broadcastMessage("message.party_new_owner", [
                "player" => $owner->getDisplayName()
            ]);
        }
    }

    public static function setMemberRole(Party $party, PlayerSession $player, int $role): void {
        $member = $party->getMember($player->getXboxId());
        if($member === null) {
            return;
        }
        $oldRole = $member->getRole();
        if($oldRole === $role) {
            return;
        }
        $owner = $party->getOwner();
        $member->setRole($role);
        $promote = $role > $oldRole;
        switch($role) {
            case PartyRole::MEMBER: {
                $player->sendTranslatedMessage("message.party_role_demoted", [
                    "role" => $player->translate("generic.role_member")
                ]);
            }
            case PartyRole::MODERATOR: {
                if($promote) {
                    $player->sendTranslatedMessage("message.party_role_promoted", [
                        "role" => $player->translate("generic.role_moderator")
                    ]);
                } else {
                    $player->sendTranslatedMessage("message.party_role_demoted", [
                        "role" => $player->translate("generic.role_moderator")
                    ]);
                }
                break;
            }
            case PartyRole::OWNER: {
                $owner?->setRole(PartyRole::MODERATOR);
                $party->broadcastMessage("message.party_new_owner", [
                    "player" => $player->getDisplayName()
                ]);
                break;
            }
        }
    }
}