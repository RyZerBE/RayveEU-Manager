<?php

declare(strict_types=1);

namespace manager;

use Exception;
use language\Language;
use libpmquery\PMQuery;
use manager\command\CommandReceiver;
use manager\endpoint\SkinEndpoint;
use manager\network\Socket;
use manager\player\PlayerSession;
use manager\player\PlayerSessionManager;
use manager\registry\CommandRegistry;
use manager\registry\GroupRegistry;
use manager\registry\PacketRegistry;
use manager\server\group\GroupManager;
use manager\server\ServerManager;
use manager\task\AsyncPool;
use manager\task\AsyncTask;
use manager\task\TaskManager;
use manager\thread\Thread;
use manager\thread\ThreadManager;
use manager\updater\PluginUpdater;
use manager\util\Database;
use manager\util\Logger;
use manager\util\Proxy;
use manager\util\WebhookManager;
use manager\util\Whitelist;
use mysqli;
use restapi\endpoint\PlayersEndpoint;
use restapi\endpoint\ServerEndpoint;
use restapi\RestAPI;
use function exec;
use function function_exists;
use function gc_collect_cycles;
use function gc_enable;
use function gc_mem_caches;
use function getmypid;
use function microtime;
use function mkdir;
use function pcntl_signal_dispatch;
use function str_replace;
use function time;
use function usleep;

class Manager {
    public const TICKS_PER_SECOND = 40;

    protected static Manager $instance;

    protected bool $running = true;

    protected int $tick = 0;

    protected string $password;

    protected string $address = "0.0.0.0";
    protected int $port = 13841;

    protected Socket $socket;

    private bool $pcntl_signal;

    /** @var string[]  */
    private array $playersToCheck = [];

    private PluginUpdater $pluginUpdater;

    private Whitelist $whitelist;

    private bool $proxyConnection = true;

    public function __construct(){
        self::$instance = $this;

        exec("sudo echo");

        date_default_timezone_set("Europe/Berlin");

        Logger::info("Registered auto loader!");
        Logger::info("PHP Version: ".PHP_VERSION);
        Logger::info("Pid: ".getmypid());
        Logger::info("Starting manager...");

        $this->whitelist = new Whitelist();

        @mkdir(self::getBasePath() . "template");
        @mkdir(self::getBasePath() . "template_plugins");
        @mkdir(self::getBasePath() . "server");

        $this->address = exec("ifconfig | grep -Eo 'inet (addr:)?([0-9]*\.){3}[0-9]*' | grep -Eo '([0-9]*\.){3}[0-9]*' | grep -v '127.0.0.1'");

        $this->password = uniqid("", true).uniqid("", true);

        @cli_set_process_title("RayveEU Manager");

        new AsyncPool();
        new TaskManager();
        new ThreadManager();
        new ServerManager();
        new GroupManager();
        new WebhookManager();

        new PacketRegistry();
        new CommandRegistry();
        new GroupRegistry();

        ThreadManager::getInstance()->addThread(new SkinEndpoint($this->address, 8899));

        ThreadManager::getInstance()->addThread(new CommandReceiver());
        $this->socket = new Socket($this->address, $this->port);
        $this->socket->incomingPackets = new \ThreadedArray();
        $this->socket->outgoingPackets = new \ThreadedArray();
        ThreadManager::getInstance()->addThread($this->socket);

        $mysqli = self::createMySQLConnection();

        Logger::info("Check database...");
        Database::setup($mysqli);

        Logger::info("Load languages...");
        $this->loadLanguageKeys($mysqli);

        mysqli_close($mysqli);

        try {
            PMQuery::query("37.114.34.206", 19132);

            foreach(ServerEndpoint::list() as $serverResponse) {
                ServerEndpoint::removeServer($serverResponse->name);
            }
            Logger::info("Successfully established connection with proxy.");
        } catch(Exception $exception) {
            Logger::error("Could not find proxy.");

            exec("kill -9 " . getmypid());
            return;
        }

        $this->pluginUpdater = new PluginUpdater();

        if($this->running) {
            if($this->pcntl_signal = function_exists("pcntl_signal")){
                pcntl_signal(SIGTERM, [$this, "handleSignal"]);
                pcntl_signal(SIGINT, [$this, "handleSignal"]);
                pcntl_signal(SIGHUP, [$this, "handleSignal"]);
                Logger::info("pcntl_signal extension found. Successfully registered pcntl_signal handler.");
            }

            ThreadManager::getInstance()->addThread(new class() extends Thread {
                public function onRun(): void{
                    while($this->isRunning()) {
                        //Keep sudo permission alive
                        exec("sudo -v");
                        sleep(2);
                    }
                }
            });

            Logger::info("Done!");
        } else {
            Logger::error("Start failed!");
        }

        while($this->running) {
            $this->tick();
        }

        echo "\n";
        Logger::info("Stopping manager...");

        foreach(PlayerSessionManager::getSessions() as $session) {
            $session->store(function(): void {});
        }
        while(count(array_filter(PlayerSessionManager::getSessions(), function(PlayerSession $session): bool {
            return $session->isInitialized();
        })) > 0) {
            AsyncPool::getInstance()->tick();
            ThreadManager::getInstance()->tick();
        }

        $serverKiller = new class() extends AsyncTask {
            public function onRun(): void{
                $time = time();
                while(!$this->worker->isShutdown() && ($time + 30) >= time()) {
                    usleep(2000);
                }
                if($this->worker->isShutdown()) {
                    return;
                }
                Logger::warning("Killed manager because of broken thread.");
                exec("kill -9 " . getmypid());
            }
        };
        AsyncPool::getInstance()->submitAsyncTask($serverKiller);

        ServerManager::getInstance()->shutdown();

        ThreadManager::getInstance()->shutdown();
        AsyncPool::getInstance()->shutdown();

        $this->whitelist->save();

        Logger::info("Goodbye!");
        sleep(1);
        exec("kill -9 " . getmypid());
    }

    public static function getInstance(): Manager{
        return self::$instance;
    }

    public function getPluginUpdater(): PluginUpdater{
        return $this->pluginUpdater;
    }

    protected function tick(): void {
        $microtime = microtime(true);

        try {
            PMQuery::query("37.114.34.206", 19132);

            if(!$this->proxyConnection) {
                $this->proxyConnection = true;
                ServerEndpoint::removeServer("Lobby-");
                ServerEndpoint::removeServer("Lobby-1");

                Logger::info("Proxy connection is back. Re-registering all servers...");

                foreach(ServerManager::getInstance()->getServers() as $server) {
                    ServerManager::getInstance()->registerServer($server);
                }
            }

            if($this->pcntl_signal) {
                pcntl_signal_dispatch();
            }

            AsyncPool::getInstance()->tick();
            ThreadManager::getInstance()->tick();
            TaskManager::getInstance()->tick();
            GroupManager::getInstance()->tick();
            ServerManager::getInstance()->tick();

            $this->pluginUpdater->tick($this->tick);

            if($this->tick % 10 === 0) {
                if(count($this->playersToCheck) <= 0) {
                    $this->playersToCheck = array_map(function(PlayerSession $session): string {
                        return $session->getXboxId();
                    }, PlayerSessionManager::getSessions());
                } else {
                    $xboxId = array_shift($this->playersToCheck);
                    $session = PlayerSessionManager::getSessionByXboxId($xboxId);
                    if($session !== null && $session->isInitialized()) {
                        $session->checkOnlineState();
                    }
                }
            }

            if(++$this->tick === PHP_INT_MAX){
                $this->tick = 0;
            }

            if($this->tick % (self::TICKS_PER_SECOND * 60 * 30) === 0) {
                Logger::debug("Run garbage collection...");

                $this->loadLanguageKeys($mysql = self::createMySQLConnection());
                mysqli_close($mysql);

                foreach(AsyncPool::getInstance()->getWorkers() as $id => $worker) {
                    AsyncPool::getInstance()->submitAsyncTask(new class() extends AsyncTask {
                        public function onRun(): void{
                            gc_enable();
                            gc_collect_cycles();
                            gc_mem_caches();
                        }
                    }, $id);
                }
                gc_collect_cycles();
                gc_mem_caches();

                foreach(GroupManager::getInstance()->getGroups() as $group) {
                    $group->resetBlockedIds();
                    foreach(ServerManager::getInstance()->getServersByGroup($group) as $server) {
                        $group->blockId($server->getId());
                    }
                }
            }

            if(!$this->socket->isRunning()) {
                $this->shutdown();
                Logger::warning("Forced manager shutdown because socket thread is not running.");
                return;
            }
        } catch(Exception $exception) {
            if($this->proxyConnection) {
                Logger::error("Lost connection to proxy. Retrying...");
            }
            $this->proxyConnection = false;
            return;
        }

        $sleep = (1000000 / self::TICKS_PER_SECOND) - ((microtime(true) - $microtime) * 1000000);
        if($sleep < 0) {
            $sleep = 0;
        }
        usleep((int)$sleep);
    }

    public static function getBasePath(): string {
        return str_replace("src/manager", "", __DIR__);
    }

    public function shutdown(): void {
        $this->running = false;
    }

    private function loadLanguageKeys(mysqli $mysqli): void {
        new Language($mysqli);
    }

    public static function createMySQLConnection(): mysqli {
        $mySQLLoginData = json_decode(file_get_contents(self::getBasePath()."../Source/mysql.json"), true);
        return mysqli_connect(
            $mySQLLoginData["address"],
            $mySQLLoginData["user"],
            $mySQLLoginData["password"],
            $mySQLLoginData["database"],
        );
    }

    public function getTick(): int{
        return $this->tick;
    }

    public function getPassword(): string{
        return $this->password;
    }

    public function getAddress(): string{
        return $this->address;
    }

    public function getPort(): int{
        return $this->port;
    }

    public function getSocket(): Socket{
        return $this->socket;
    }

    protected function handleSignal($signal){
        if($signal === SIGTERM || $signal === SIGINT || $signal === SIGHUP){
            $this->shutdown();
        }
    }

    public function getWhitelist(): Whitelist{
        return $this->whitelist;
    }

    public function setWhitelist(Whitelist $whitelist): void{
        $this->whitelist = $whitelist;
    }
}