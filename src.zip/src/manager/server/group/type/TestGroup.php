<?php

declare(strict_types=1);

namespace manager\server\group\type;

use manager\server\group\Group;

class TestGroup extends Group {
    public function getFileName(): string{
        return "Testserver";
    }

    public function getItem(): string{
        return "element_zero";
    }
}