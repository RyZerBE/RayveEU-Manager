<?php

declare(strict_types=1);

namespace manager\server\group\type;

use manager\server\group\Group;

class ReplayGroup extends Group{
    public function getFileName(): string{
        return "Replay";
    }

    public function getItem(): string{
        return "clock";
    }

    public function getMinServer(): int{
        return 0;
    }
}