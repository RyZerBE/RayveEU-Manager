<?php

declare(strict_types=1);

namespace manager\server\group\type;

use manager\server\group\Group;

class SumoGroup extends Group{
    public function getFileName(): string{
        return "Sumo";
    }

    public function isGameServer(): bool{
        return true;
    }

    public function getItem(): string{
        return "feather";
    }

    public function getMaxServerAmount(): int{
        return 1;
    }
}