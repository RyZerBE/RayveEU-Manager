<?php

declare(strict_types=1);

namespace manager\server\group\type;

use lookup\GroupIds;
use manager\server\group\Group;

class LobbyGroup extends Group {
    protected int $minServer = 2;

    public function getFileName(): string{
        return GroupIds::LOBBY;
    }

    public function isDefault(): bool{
        return true;
    }

    public function getItem(): string{
        return "bed";
    }
}