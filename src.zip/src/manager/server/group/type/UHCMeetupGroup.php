<?php

declare(strict_types=1);

namespace manager\server\group\type;

use lookup\ServerSetting;
use manager\server\group\Group;
use manager\server\group\VariantsTrait;

class UHCMeetupGroup extends Group{
    use VariantsTrait;

    public function getFileName(): string{
        return "UHCMeetup";
    }

    public function isGameServer(): bool{
        return true;
    }

    public function getItem(): string{
        return "iron_sword";
    }

    public function getVariants(): array{
        return [
            "16x1" => [
                ServerSetting::TEAMS => 16,
                ServerSetting::PLAYERS_PER_TEAM => 1,
            ],
            "8x2" => [
                ServerSetting::TEAMS => 8,
                ServerSetting::PLAYERS_PER_TEAM => 2,
            ],
            "8x3" => [
                ServerSetting::TEAMS => 8,
                ServerSetting::PLAYERS_PER_TEAM => 3,
            ],
        ];
    }
}