<?php

declare(strict_types=1);

namespace manager\server\group\type;

use manager\server\group\Group;

class FFAGroup extends Group{
    public function getFileName(): string{
        return "FFA";
    }

    public function isGameServer(): bool{
        return true;
    }

    public function getItem(): string{
        return "iron_sword";
    }

    public function getMaxServerAmount(): int{
        return 1;
    }
}