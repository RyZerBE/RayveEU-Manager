<?php

declare(strict_types=1);

namespace manager\server\group\type;

use lookup\GroupIds;
use lookup\ServerSetting;
use manager\server\group\Group;
use manager\server\group\VariantsTrait;
use manager\server\Server;

class KitWarsGroup extends Group{
    use VariantsTrait;

    public function getFileName(): string{
        return "KitWars";
    }

    public function isGameServer(): bool{
        return true;
    }

    public function getItem(): string{
        return "chest";
    }

    public function getVariants(): array{
        return [
            "2x1" => [
                ServerSetting::TEAMS => 2,
                ServerSetting::PLAYERS_PER_TEAM => 1,
            ],
            "2x2" => [
                ServerSetting::TEAMS => 2,
                ServerSetting::PLAYERS_PER_TEAM => 2,
            ],
            "4x1" => [
                ServerSetting::TEAMS => 4,
                ServerSetting::PLAYERS_PER_TEAM => 1,
            ],
            "4x2" => [
                ServerSetting::TEAMS => 4,
                ServerSetting::PLAYERS_PER_TEAM => 2,
            ],
        ];
    }
}