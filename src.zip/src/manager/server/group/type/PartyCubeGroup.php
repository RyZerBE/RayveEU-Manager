<?php

declare(strict_types=1);

namespace manager\server\group\type;

use manager\server\group\Group;

class PartyCubeGroup extends Group{
    public function getFileName(): string{
        return "PartyCube";
    }

    public function isGameServer(): bool{
        return true;
    }

    public function getItem(): string{
        return "cake";
    }
}