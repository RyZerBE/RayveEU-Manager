<?php

declare(strict_types=1);

namespace manager\server\group;

use manager\Manager;
use manager\util\Logger;

class GroupManager {
    private static GroupManager $instance;

    /** @var Group[]  */
    private array $groups = [];

    public function __construct(){
        self::$instance = $this;
    }

    public static function getInstance(): GroupManager{
        return self::$instance;
    }

    public function getGroups(): array{
        return $this->groups;
    }

    public function getGroup(string $group): ?Group {
        return $this->groups[$group] ?? null;
    }

    public function registerGroup(Group $group): void {
        $properties = @file_get_contents(Manager::getBasePath()."template/".$group->getFileName()."/server.properties");
        if(!is_string($properties) || !str_contains($properties, "PORT") || !str_contains($properties, "NAME")) {
            Logger::warning("Group ".$group->getFileName()." could not be registered. Reason: Invalid server.properties file");
            return;
        }
        $this->groups[$group->getFileName()] = $group;
        Logger::info("Successfully registered group ".$group->getFileName().".");
    }

    public function tick(): void {
        $currentTick = Manager::getInstance()->getTick();
        foreach($this->getGroups() as $group) {
            $group->defaultTick($currentTick);
            $group->tick($currentTick);
        }
    }
}