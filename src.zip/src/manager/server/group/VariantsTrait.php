<?php

declare(strict_types=1);

namespace manager\server\group;

use lookup\ServerSetting;
use manager\server\Server;
use manager\server\ServerManager;

trait VariantsTrait{
    abstract public function getVariants(): array;

    public function getMinServer(): int{
        return count($this->getVariants());
    }

    public function onServerQueue(Server $server): void{
        $variants = [];

        foreach(ServerManager::getInstance()->getServersByGroup($this) as $onlineServer) {
            if($onlineServer->isBlocked() || $onlineServer->isCustom() || $onlineServer->isFlaggedForShutdown()) {
                continue;
            }
            $settings = $onlineServer->getSettings();
            $key = $settings[ServerSetting::TEAMS]."x".$settings[ServerSetting::PLAYERS_PER_TEAM];
            if(!isset($variants[$key])) {
                $variants[$key] = 0;
            }
            $variants[$key]++;
        }
        foreach($this->getVariants() as $key => $data) {
            if(!isset($variants[$key])) {
                $server->setSettings($data);
                return;
            }
        }
        asort($variants);
        $variant = array_key_first($variants);
        $settings = $this->getVariants()[$variant] ?? null;
        if($settings === null) {
            $settings = $this->getVariants()[array_rand($this->getVariants())];
        }
        $server->setSettings($settings);
    }
}