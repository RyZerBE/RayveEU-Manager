<?php

declare(strict_types=1);

namespace manager\server\group;

use DateTime;
use DateTimeZone;
use discord\color\DiscordColors;
use discord\DiscordMessage;
use discord\embed\DiscordEmbed;
use manager\Manager;
use manager\server\Server;
use manager\server\ServerManager;
use manager\util\Logger;

abstract class Group{
    protected int $id = 0;

    abstract public function getFileName(): string;

    protected int $minServer = 1;

    public int $serverCooldown = 0;

    /** @var int[]  */
    private array $blockedIds = [];

    public int $crashes = 0;
    public int $lastCrash = 0;

    private int $lastId = 0;

    public bool $requiresUpdate = true;

    public int $scheduledServerRestart = -1;

    public function addCrash(): void {
        $this->crashes++;
        $this->lastCrash = time();
    }

    public function resetCrashes(): void {
        $this->crashes = 0;
        $this->lastCrash = 0;
    }

    public function resetBlockedIds(): void {
        $this->blockedIds = [];
    }

    public function hasCrashLimitReached(): bool {
        return $this->crashes >= 3 && (time() - $this->lastCrash) <= 30;
    }

    public function getMaxServerAmount(): int {
        return PHP_INT_MAX;
    }

    public function getMinServer(): int{
        return $this->minServer;
    }

    public function setMinServer(int $minServer): void{
        $this->minServer = $minServer;
    }

    public function isDefault(): bool {
        return false;
    }

    public function isGameServer(): bool {
        return false;
    }

    public function blockId(int $id): void {
        $this->blockedIds[] = $id;
    }

    public function unblockId(int $id): void {
        $key = array_search($id, $this->blockedIds, true);
        if($key === false) {
            return;
        }
        unset($this->blockedIds[$key]);
    }

    public function getUsableId(): int {
        $id = 1;
        while(in_array($id, $this->blockedIds, true) || $id === $this->lastId) {
            $id++;
        }
        $this->lastId = $id;
        return $id;
    }

    /**
     * @return Server[]
     */
    public function getAvailableServers(): array {
        return array_filter(ServerManager::getInstance()->getServersByGroup($this), function(Server $server): bool {
            return $server->isOnline() && !$server->isFlaggedForShutdown() && !$server->isBlocked() && !$server->isCustom();
        });
    }

    public function getServersInQueue(): array {
        return array_filter(array_merge(ServerManager::getInstance()->getStartupQueue(), array_filter(ServerManager::getInstance()->getServersByGroup($this), function(Server $server): bool {
            return $server->startup || !$server->online;
        })), function(Server $server): bool {
            return $server->getGroup()->getFileName() === $this->getFileName();
        });
    }

    public function tick(int $tick): void {
    }

    public function defaultTick(int $tick): void {
        if($this->scheduledServerRestart !== -1 && time() > $this->scheduledServerRestart) {
            $this->scheduledServerRestart = -1;
            foreach(ServerManager::getInstance()->getServersByGroup($this) as $server) {
                $server->flagForShutdown();
            }
        }

        if($this->hasCrashLimitReached()) {
            $this->serverCooldown = Manager::TICKS_PER_SECOND * 50;
            Logger::warning("Group ".$this->getFileName()." was blocked for ".floor($this->serverCooldown / 20)." seconds due to many crashes.");

            $webhook = new DiscordMessage("https://discord.com/api/webhooks/1070015723449094242/VlRw8NPqZDYPnfN6dz42envS4XeYWuejk103IuYGkg-GM9SOc_AOf9xBoF7-AwsnNRpd");
            $webhook->setMessage("<@350941156722606081>");
            $embed = new DiscordEmbed();
            $embed->setTitle("Crash limit reached");
            $embed->setColor(DiscordColors::DARK_RED);
            $embed->setDescription("Group ".$this->getFileName()." crashed too many times in a short period.");
            $embed->setDateTime(new DateTime("now", new DateTimeZone("Europe/Berlin")));
            $webhook->addEmbed($embed);
            $webhook->send();

            $this->resetCrashes();
            return;
        }
        if(--$this->serverCooldown > 0) {
            return;
        }

        $count = count($servers = array_filter(ServerManager::getInstance()->getServersByGroup($this), function(Server $server): bool {
            return !$server->isFlaggedForShutdown() && $server->isOnline();
        }));
        if($count > $this->getMaxServerAmount()) {
            $server = array_pop($servers);
            $server->flagForShutdown();
        }

        $available = $this->getAvailableServers();
        if(count($available) > $this->getMinServer()) {
            $server = array_shift($available);
            $server?->flagForShutdown();
        }

        if((count($available) + count($this->getServersInQueue())) >= $this->getMinServer()) {
            return;
        }
        $id = $this->getUsableId();
        $port = ServerManager::getInstance()->getUsablePort();

        if($this->requiresUpdate) {
            $path = Manager::getBasePath()."../";
            @exec($path."Source/bin/php7/bin/php ".$path."Source/update_plugins.php ".Manager::getBasePath()."template_plugins/".$this->getFileName()."/");

            Logger::debug("Updated group ".$this->getFileName().".");
        }

        $this->blockId($id);

        $server = new Server($this, $id, $port);
        $server->queueStartup();
        $this->onServerQueue($server);

        ServerManager::getInstance()->registerServer($server, $this->isDefault());

        $this->serverCooldown = Manager::TICKS_PER_SECOND / 2;
    }


    public function onServerQueue(Server $server): void {
    }

    abstract public function getItem(): string;
}