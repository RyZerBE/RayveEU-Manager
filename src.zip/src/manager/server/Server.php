<?php

declare(strict_types=1);

namespace manager\server;

use Closure;
use manager\Manager;
use manager\network\packet\GameServerSettingsPacket;
use manager\network\packet\Packet;
use manager\player\PlayerSession;
use manager\player\PlayerSessionManager;
use manager\server\group\Group;
use manager\server\helper\ShutdownHelper;
use manager\server\helper\StartupHelper;
use manager\task\AsyncPool;
use manager\util\Logger;
use rayveeu\essentials\player\Session;
use restapi\endpoint\PlayerEndpoint;

class Server {
    public const TIMEOUT = Manager::TICKS_PER_SECOND * 20;

    protected string $uniqueIdentifier;
    protected ?string $name = null;

    protected ServerStatus $status;


    public bool $online = false;
    public bool $startup = false;
    public bool $startAttempted = false;

    protected bool $custom = false;
    protected bool $blocked = false;
    protected bool $flaggedForShutdown = false;

    protected int $timeout = 0;
    protected int $startupTime = -1;

    protected array $settings = [];

    public int $reRegistries = 0;

    public ?Closure $whenOnline = null;

    private array $rejoinCache = [];

    public function __construct(
        protected Group $group,
        protected int $id,
        protected int $port,
    ){
        $this->uniqueIdentifier = uniqid('', true);
        $this->status = new ServerStatus();
    }

    public function setName(?string $name): void{
        $this->name = $name;
    }

    public function getName(): string{
        return ($this->name ?? $this->group->getFileName())."-".$this->id;
    }

    public function getStatus(): ServerStatus{
        return $this->status;
    }

    public function isOnline(): bool{
        return $this->online;
    }

    public function getUniqueIdentifier(): string{
        return $this->uniqueIdentifier;
    }

    public function getGroup(): Group{
        return $this->group;
    }

    public function getId(): int{
        return $this->id;
    }

    public function getPort(): int{
        return $this->port;
    }

    public function hasTimeout(): bool {
        return $this->timeout >= self::TIMEOUT && $this->startAttempted;
    }

    public function resetTimeout(): void {
        $this->timeout = 0;
    }

    public function tick(): void {
        if($this->reRegistries > 3 || ($this->status->onlinePlayers <= 0 && $this->isCustom() && $this->getRuntime() > 30)) {
            $this->flagForShutdown();
        }

        $this->timeout++;
        if($this->hasTimeout()) {
            Logger::debug($this->getName().": Timeout.");
            $this->shutdown();
        } elseif($this->status->onlinePlayers <= 0 && $this->isFlaggedForShutdown()) {
            Logger::debug($this->getName().": Empty and flagged for shutdown.");
            $this->shutdown();
        }
    }

    public function finishStartup(): void {
        if($this->group->isGameServer()) {
            $packet = new GameServerSettingsPacket();
            $packet->settings = $this->getSettings();
            $this->sendPacket($packet);
        }
    }

    public function flagForShutdown(): void {
        $this->flaggedForShutdown = true;
    }

    public function isFlaggedForShutdown(): bool{
        return $this->flaggedForShutdown;
    }

    public function queueStartup(): void {
        $this->startup = true;
        ServerManager::getInstance()->queueServerStartup($this);
    }

    public function startup(): void {
        $this->startupTime = time();
        $this->startup = true;
        $this->startAttempted = true;
        $this->timeout = 0;
        new StartupHelper($this);
    }

    public function shutdown(bool $kill = false): void {
        new ShutdownHelper($this, $kill, !$this->online);
        $this->online = false;
        if($kill) {
            foreach(PlayerSessionManager::getSessions() as $session) {
                $session->checkOnlineState();
            }
        }
    }

    public function sendPacket(Packet $packet): void {
        $packet->uniqueID = $this->getUniqueIdentifier();
        $packet->send();
    }

    public function setWhenOnline(?Closure $whenOnline): void{
        $this->whenOnline = $whenOnline;
    }

    public function setCustom(bool $custom): void{
        $this->custom = $custom;
    }

    public function isCustom(): bool{
        return $this->custom;
    }

    public function getRuntime(): int {
        if($this->startupTime === -1) {
            return 0;
        }
        return time() - $this->startupTime;
    }

    public function setBlocked(bool $blocked): void{
        $this->blocked = $blocked;
    }

    public function isBlocked(): bool{
        return $this->blocked;
    }

    public function getSettings(): array{
        return $this->settings;
    }

    public function setSettings(array $settings): void{
        $this->settings = $settings;
    }

    public function addToRejoinCache(string $xboxId): void {
        $this->rejoinCache[] = $xboxId;
    }

    public function getRejoinCache(): array{
        return $this->rejoinCache;
    }

    public function isInRejoinCache(PlayerSession $session): bool {
        return in_array($session->getXboxId(), $this->rejoinCache, true);
    }

    public function asArray(): array {
        return [
            $this->getName(),
            $this->getPort(),
            $this->group->getFileName(),
            $this->status->onlinePlayers,
            $this->status->maxOnlinePlayers,
            $this->status->tpsAverage,
            $this->status->tickUsageAverage,
            $this->status->packetDelay,
            $this->custom,
            $this->online,
            $this->group->getItem(),
            $this->blocked,
            $this->settings,
        ];
    }
}