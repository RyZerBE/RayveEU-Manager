<?php

declare(strict_types=1);

namespace manager\server;

use manager\Manager;
use manager\server\group\Group;
use manager\server\group\type\LobbyGroup;
use manager\task\AsyncPool;
use manager\thread\ThreadManager;
use manager\util\Logger;
use manager\util\Proxy;
use restapi\endpoint\ServerEndpoint;

class ServerManager {
    public const START_PORT = 10000;
    
    private static ServerManager $instance;

    /** @var Server[]  */
    private array $servers = [];

    /** @var int[]  */
    private array $blockedPorts = [];

    /** @var Server[]  */
    private array $startupQueue = [];
    private ?Server $currentStartup = null;
    
    public function __construct(){
        self::$instance = $this;
    }

    public static function getInstance(): ServerManager{
        return self::$instance;
    }

    public function getServers(): array{
        return $this->servers;
    }

    public function getServerByPort(int $port): ?Server {
        return $this->servers[$port] ?? null;
    }

    public function getServerByUniqueID(string $id): ?Server {
        foreach($this->servers as $server) {
            if($server->getUniqueIdentifier() === $id) {
                return $server;
            }
        }
        return null;
    }

    public function getServerByName(string $name): ?Server {
        foreach($this->servers as $server) {
            if($server->getName() === $name) {
                return $server;
            }
        }
        return null;
    }

    /**
     * @return Server[]
     */
    public function getServersByGroup(Group $group): array {
        $name = $group->getFileName();
        return array_filter($this->getServers(), function(Server $server) use ($name): bool {
            return $server->getGroup()->getFileName() === $name;
        });
    }

    public function queueServerStartup(Server $server): void {
        if($server->getGroup()->getFileName() === "Lobby") {
            $server->startup();
            return;
        }
        $this->startupQueue[] = $server;
    }

    public function getStartupQueue(): array{
        return $this->startupQueue;
    }

    public function registerServer(Server $server, bool $default = false): void {
        $serverPort = $server->getPort();
        $this->servers[$serverPort] = $server;
        $address = Manager::getInstance()->getAddress();
        $name = $server->getName();
        AsyncPool::getInstance()->submitClosure(function() use ($name, $serverPort, $address): void {
            ServerEndpoint::addServer($name, $address, $serverPort);
        });
    }

    public function unregisterServer(Server $server): void {
        $serverPort = $server->getPort();
        unset($this->servers[$serverPort]);
        $name = $server->getName();
        AsyncPool::getInstance()->submitClosure(function() use ($name): void {
            ServerEndpoint::removeServer($name);
        });
    }

    public function getUsablePort(): int {
        $port = self::START_PORT;
        while (isset($this->servers[$port]) || $this->isPortBlocked($port)) {
            $port++;
        }
        return $port;
    }

    public function tick(): void {
        foreach($this->getServers() as $server) {
            $server->tick();
        }

        if($this->currentStartup === null || $this->currentStartup->isOnline() || Manager::getInstance()->getTick() % (Manager::TICKS_PER_SECOND) === 0) {
            $server = array_shift($this->startupQueue);
            if($server instanceof Server) {
                $server->startup();
            }
            $this->currentStartup = $server;
        }

        if(Manager::getInstance()->getTick() % (Manager::TICKS_PER_SECOND * 60) === 0) {
            foreach(ServerEndpoint::list() as $serverResponse) {
                if($this->getServerByName($serverResponse->name) === null) {
                    ServerEndpoint::removeServer($serverResponse->name);
                }
            }
        }
    }

    public function isPortBlocked(int $port): bool {
        return in_array($port, $this->blockedPorts, true);
    }

    public function getBlockedPorts(): array{
        return $this->blockedPorts;
    }

    public function blockPort(int $port): void {
        $this->blockedPorts[] = $port;
    }

    public function unblockPort(int $port): void {
        $key = array_search($port, $this->blockedPorts, true);
        if($key === false) {
            return;
        }
        unset($this->blockedPorts[$key]);
    }

    public function shutdown(): void {
        foreach($this->getServers() as $server) {
            Logger::debug($server->getName().": Manager shutdown.");
            $server->shutdown();
        }
        $timeout = time() + 10;
        while(time() < $timeout) {
            AsyncPool::getInstance()->tick();
            ThreadManager::getInstance()->tick();
            if(count($this->getBlockedPorts()) <= 0 && count($this->getServers()) <= 0) {
                break;
            }
        }
        foreach($this->getServers() as $server) {
            Logger::debug($server->getName().": Manager shutdown.");
            $server->shutdown(true);
        }
        sleep(1);
        @exec("rm -r ".Manager::getBasePath()."server/*");
    }
}