<?php

declare(strict_types=1);

namespace manager\server\helper;

use manager\Manager;
use manager\network\packet\SendMessagePacket;
use manager\player\PlayerSessionManager;
use manager\server\Server;
use manager\task\AsyncPool;
use manager\util\FileUtils;
use manager\util\Logger;

class StartupHelper {
    public function __construct(Server $server){
        $group = $server->getGroup();

        $filename = $server->getGroup()->getFileName();
        $name = $server->getName();
        $port = $server->getPort();
        $password = Manager::getInstance()->getPassword();
        $managerPort = Manager::getInstance()->getPort();
        $uniqueID = $server->getUniqueIdentifier();
        $update = $group->requiresUpdate;
        $group->requiresUpdate = false;
        $group->scheduledServerRestart = -1;
        AsyncPool::getInstance()->submitClosure(function() use ($filename, $name, $port, $password, $uniqueID, $managerPort, $update): bool {
            $serverPath = Manager::getBasePath()."server/".$name."/";
            $defaultFilesPath = Manager::getBasePath()."template/Default";
            $templatePath = Manager::getBasePath()."template/".$filename;
            $templatePluginsPath = Manager::getBasePath()."template_plugins/".$filename;

            if(!is_file($templatePath."/server.properties")) {
                Logger::error("server.properties file in '".$templatePath."' is missing");
                return false;
            }

            exec("screen -XS ".$name." kill");
            exec("fuser -k ".$port."/udp");

            if(is_dir($serverPath)) {
                FileUtils::delete($serverPath);
            }
            FileUtils::copy($defaultFilesPath, $serverPath);
            usleep(100);
            FileUtils::copy($templatePath, $serverPath);
            usleep(100);

            $properties = file_get_contents($serverPath."server.properties");
            if(!is_string($properties)) {
                Logger::error("Could not open server.properties in '".$serverPath."'");
                return false;
            }
            exec("sudo chmod -R 777 ".$serverPath);
            file_put_contents($serverPath."server.properties",
                str_replace([
                    "PASSWORD",
                    "MANAGER_PORT",
                    "UNIQUE_ID",
                    "PORT",
                    "NAME",
                ], [
                    $password,
                    $managerPort,
                    $uniqueID,
                    $port,
                    $name,
                ], $properties)
            );

            $path = Manager::getBasePath()."../";

            if($update) {
                exec($path."Source/bin_manager/php7/bin/php ".$path."Source/update_plugins.php ".$templatePluginsPath."/");
            }
            usleep(100);
            exec("sudo ".implode(" && ", [
                "cp ".$path."Source/PocketMine*.phar ".$serverPath." -r",
                "cd ".$serverPath,
                "sleep 1",
                "screen -AmdS ".$name." ".$path."Source/bin/php7/bin/php PocketMine*.phar --plugins ".$templatePluginsPath,
            ]));
            return true;
        }, function(bool $success) use ($server): void {
            $server->startup = false;
            if($success) {
                Logger::debug("Server startup of ".$server->getName()." was successful.");
                PlayerSessionManager::getSessionByXboxId("2535461863475069")?->sendMessage("§l§fCloud §7|§r Server ".$server->getName()." is now online.");
                return;
            }
            Logger::warning("Server startup of ".$server->getName()." has failed.");
            Logger::debug($server->getName().": Startup failed.");
            $server->shutdown(true);
        });
    }
}