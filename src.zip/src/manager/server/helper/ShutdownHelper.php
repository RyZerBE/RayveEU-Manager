<?php

declare(strict_types=1);

namespace manager\server\helper;

use DateTime;
use DateTimeZone;
use discord\color\DiscordColors;
use discord\DiscordMessage;
use discord\embed\DiscordEmbed;
use libpmquery\PMQuery;
use libpmquery\PmQueryException;
use manager\Manager;
use manager\network\packet\ServerShutdownPacket;
use manager\server\Server;
use manager\server\ServerManager;
use manager\task\AsyncPool;
use manager\util\FileUtils;
use manager\util\Logger;

class ShutdownHelper {
    public function __construct(Server $server, bool $kill, bool $probablyCrashed){
        $server->sendPacket(new ServerShutdownPacket());

        $name = $server->getName();
        $port = $server->getPort();
        $address = Manager::getInstance()->getAddress();

        ServerManager::getInstance()->unregisterServer($server);
        ServerManager::getInstance()->blockPort($port);

        $serverPath = Manager::getBasePath()."server/".$name."/";

        AsyncPool::getInstance()->submitClosure(function() use ($name, $port, $kill, $serverPath, $address, $probablyCrashed): bool {
            $fails = 0;
            while(true) {
                usleep(700000);
                try{
                    PMQuery::query($address, $port, 5);
                    if(++$fails >= 10) {
                        $kill = true;
                        break;
                    }
                } catch(PmQueryException $exception) {
                    break;
                }
            }

            if($kill) {
                exec("screen -XS ".$name." kill");
                exec("fuser -k ".$port."/udp");
            }

            $crashed = false;

            $crashdumpPath = $serverPath."crashdumps";
            if(is_dir($crashdumpPath)) {
                foreach(scandir($crashdumpPath) as $crashdump) {
                    if(!is_file($crashdumpPath."/".$crashdump)) {
                        continue;
                    }
                    $crashdump = str_split(file_get_contents($crashdumpPath."/".$crashdump), 1000)[0]."...";

                    $webhook = new DiscordMessage("https://discord.com/api/webhooks/1070015723449094242/VlRw8NPqZDYPnfN6dz42envS4XeYWuejk103IuYGkg-GM9SOc_AOf9xBoF7-AwsnNRpd");
                    $webhook->setMessage("Server ".$name." crashed...");
                    $embed = new DiscordEmbed();
                    $embed->setTitle("Crashdump");
                    $embed->setColor(DiscordColors::DARK_RED);
                    $embed->setDescription($crashdump);
                    $embed->setDateTime(new DateTime("now", new DateTimeZone("Europe/Berlin")));
                    $webhook->addEmbed($embed);
                    $webhook->send();

                    $crashed = true;
                }
            }
            $content = null;
            if(is_file($serverPath."server.log")) {
                $content = file_get_contents($serverPath."server.log");
                if($crashed) {
                    var_dump($content);
                }
            }
            if(($probablyCrashed || $crashed) && is_string($content)) {
                $split = str_split($content, 1000);

                $webhook = new DiscordMessage("https://discord.com/api/webhooks/1124274924190703636/RLKqA_0nSvvMdJsyTnjhfOMQo6ggjeq_rVgksZOHNM95bJ2UVWrFi_T3ZbXzhxwvCL8Z");
                if($crashed) {
                    $webhook->setMessage("Server ".$name." crashed.");
                } else {
                    $webhook->setMessage("Server ".$name." crashed probably...");
                }

                $page = 1;
                foreach($split as $content) {
                    $embed = new DiscordEmbed();
                    $embed->setColor($crashed ? DiscordColors::DARK_RED : DiscordColors::RED);
                    $embed->setDescription($content ?? "???");
                    $embed->setDateTime(new DateTime("now", new DateTimeZone("Europe/Berlin")));
                    $embed->setFooter("Page ".$page++."/".count($split));
                    $webhook->addEmbed($embed);
                }
                $webhook->send();
            }
            usleep(100);
            FileUtils::delete($serverPath);
            return $crashed;
        }, function(bool $crashed) use ($kill, $server, $probablyCrashed): void {
            $server->getGroup()->unblockId($server->getId());
            ServerManager::getInstance()->unblockPort($server->getPort());
            if($crashed) {
                $server->getGroup()->addCrash();
                Logger::warning("Server ".$server->getName()." crashed.");
                return;
            }
            if($probablyCrashed) {
                $server->getGroup()->addCrash();
                Logger::warning("Server ".$server->getName()." has not started correctly but no crash was detected. Logging server.log file...");
                return;
            }
            if($kill) {
                Logger::info("Server ".$server->getName()." was killed successfully.");
                return;
            }
            Logger::info("Server ".$server->getName()." was shut down successfully.");
        });
    }
}