<?php

declare(strict_types=1);

namespace manager\server;

class ServerStatus {
    public function __construct(
        public float $tpsAverage = 0.0,
        public float $tickUsageAverage = 0.0,
        public int $onlinePlayers = 0,
        public int $maxOnlinePlayers = 0,
        public float $packetDelay = 0.0,
    ){}
}